/* React Native renderer.
 * Uses @shopify/react-native-skia for the wireframe (fast batched Path
 * drawing) and plain RN <Text> for overlay labels (no font assets needed).
 *
 * Peer deps: react-native, @shopify/react-native-skia
 */
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import {
  computeFrame,
  bucketColor,
  DEFAULT_THEME,
  LOW_QUALITY,
} from '../core/engine.js';

var Skia;
try {
  Skia = require('@shopify/react-native-skia');
} catch (e) {
  Skia = null;
}

var h = React.createElement;

export default function RoadHazardView(props) {
  var W = props.width || 360;
  var H = props.height || Math.round(W * 0.78);
  var theme = Object.assign({}, DEFAULT_THEME, props.theme);

  var _s = useState({ paths: [], overlays: [] });
  var out = _s[0], setOut = _s[1];
  var propsRef = useRef(props);
  propsRef.current = props;
  var advisoryRef = useRef(null);  // lane-advisory hysteresis state
  var celebrateRef = useRef(null); // { id, start } for celebration anim

  useEffect(function () {
    var frame = 0;
    var running = true;
    function tick() {
      if (!running) return;
      frame++;
      var p = propsRef.current;
      var cel = null;
      if (p.celebrate && p.celebrate.id != null) {
        if (!celebrateRef.current || celebrateRef.current.id !== p.celebrate.id) {
          celebrateRef.current = { id: p.celebrate.id, start: frame };
        }
        var ct = (frame - celebrateRef.current.start) / 95;
        if (ct < 1) cel = { t: ct, text: p.celebrate.text };
      }
      var res = computeFrame({
        mode: p.mode,
        sceneId: p.hazard,
        frame: frame,
        width: p.width || 360,
        height: p.height || Math.round((p.width || 360) * 0.78),
        quality: p.quality || LOW_QUALITY, // lighter default on native
        speed: p.speed,
        overlay: p.warning,
        lanes: p.lanes,
        laneQuality: p.laneQuality,
        poles: p.poles,
        advise: p.advise,
        events: p.events,
        progress: p.progress,
        viewDistance: p.viewDistance,
        route: p.route,
        showUpcoming: p.showUpcoming,
        laneConfig: p.laneConfig,
        rqi: p.rqi,
        compliance: p.compliance,
        celebrate: cel,
        environment: p.environment,
        pois: p.pois,
        driverLane: p.driverLane,
        detections: p.detections,
        show: p.show,
        prevAdvisory: advisoryRef.current,
      });
      if (res.drive && res.drive.advisory) advisoryRef.current = res.drive.advisory;
      if (p.onDriveInfo && res.drive) p.onDriveInfo(res.drive);
      setOut(res);
      requestAnimationFrame(tick);
    }
    var raf = requestAnimationFrame(tick);
    return function () {
      running = false;
      cancelAnimationFrame(raf);
    };
  }, []);

  if (!Skia) {
    return h(
      View,
      { style: [styles.fallback, { width: W, height: H }] },
      h(Text, { style: styles.fallbackText },
        'Install @shopify/react-native-skia to render RoadHazardView')
    );
  }

  var Canvas = Skia.Canvas;
  var Path = Skia.Path;

  // batched wireframe paths as SVG strings
  var children = [];
  for (var i = 0; i < out.paths.length; i++) {
    var b = out.paths[i];
    var d = '';
    var pts = b.points;
    for (var j = 0; j < pts.length; j += 4) {
      d +=
        'M' + pts[j].toFixed(1) + ' ' + pts[j + 1].toFixed(1) +
        'L' + pts[j + 2].toFixed(1) + ' ' + pts[j + 3].toFixed(1);
    }
    children.push(
      h(Path, {
        key: 'b' + i,
        path: d,
        color: bucketColor(b, theme),
        style: 'stroke',
        strokeWidth: 1,
      })
    );
  }

  // sign shapes drawn in Skia; text labels rendered as RN <Text>
  var labels = [];
  for (var k = 0; k < out.overlays.length; k++) {
    var ov = out.overlays[k];
    var ox = ov.x * W, oy = ov.y * H;
    var col = toneColor(theme, ov.tone, ov.on ? 1 : 0.35);
    if (ov.kind === 'banner') {
      labels.push(
        h(Text, {
          key: 'bn' + k,
          style: [styles.banner, { top: oy - 11, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'label') {
      labels.push(
        h(Text, {
          key: 'l' + k,
          style: [styles.label, { top: oy - 9, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'you') {
      children.push(h(Path, {
        key: 'you' + k,
        path: 'M' + ox + ' ' + (oy - 14) + 'L' + (ox - 8) + ' ' + (oy - 2) + 'L' + (ox + 8) + ' ' + (oy - 2) + 'Z',
        color: col, style: 'fill',
      }));
      labels.push(h(Text, {
        key: 'yt' + k,
        style: [styles.laneNum, { top: oy + 1, left: ox - 20, fontSize: 9, color: col }],
      }, ov.text));
    } else if (ov.kind === 'det-label') {
      labels.push(
        h(Text, {
          key: 'dl' + k,
          style: [styles.poiLabel, { top: oy - 5, left: ox - 50, width: 100, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'poi-label') {
      labels.push(
        h(Text, {
          key: 'pl' + k,
          style: [styles.poiLabel, { top: oy - 5, left: ox - 40, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'lane-num') {
      labels.push(
        h(Text, {
          key: 'ln' + k,
          style: [styles.laneNum, { top: oy - 7, left: ox - 20, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'score') {
      labels.push(
        h(Text, {
          key: 'sc' + k,
          style: [styles.score, { top: oy - 8, left: ox, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'celebrate') {
      var t = ov.phase;
      var rise = 34 * Math.min(1, t * 2.2);
      var alpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
      var pop = t < 0.18 ? t / 0.18 : 1;
      var cy = oy - rise;
      var cw = 26 * pop;
      var colA = toneColor(theme, 'accent', alpha);
      children.push(h(Path, {
        key: 'ca' + k,
        path: 'M' + ox + ' ' + (cy + cw) + 'L' + ox + ' ' + (cy - cw * 0.9) +
              'M' + (ox - cw * 0.62) + ' ' + (cy - cw * 0.2) + 'L' + ox + ' ' + (cy - cw * 0.9) +
              'L' + (ox + cw * 0.62) + ' ' + (cy - cw * 0.2),
        color: colA, style: 'stroke', strokeWidth: 4 * pop, strokeCap: 'round', strokeJoin: 'round',
      }));
      for (var st = 0; st < 6; st++) {
        var ang = (st / 6) * Math.PI * 2 + t * 2.2;
        var rr = 26 + 44 * t;
        var sx2 = ox + Math.cos(ang) * rr;
        var sy2 = cy - cw * 0.1 + Math.sin(ang) * rr * 0.62;
        var tw = 0.6 + 0.4 * Math.sin(t * 22 + st * 1.7);
        children.push(h(Path, {
          key: 'cs' + k + '_' + st,
          path: starPath(sx2, sy2, 5.5 * pop * tw),
          color: toneColor(theme, 'accent', alpha * tw), style: 'fill',
        }));
      }
      labels.push(h(Text, {
        key: 'cl' + k,
        style: [styles.banner, { top: cy + cw + 12, color: colA }],
      }, ov.text));
    } else if (ov.kind === 'queue') {
      labels.push(
        h(Text, {
          key: 'q' + k,
          style: [styles.queue, { top: oy - 6, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'subline') {
      labels.push(
        h(Text, {
          key: 'sl' + k,
          style: [styles.subline, { top: oy - 6, color: col }],
        }, ov.text)
      );
    } else if (ov.kind === 'lane-label') {
      labels.push(
        h(Text, {
          key: 'll' + k,
          style: [styles.laneLabel, { top: oy - 8, left: ox - 30, color: col }],
        }, (ov.roleText ? ov.roleText + '\n' : '') + ov.text)
      );
    } else if (ov.kind === 'sign-triangle') {
      children.push(h(Path, {
        key: 'o' + k,
        path: 'M' + ox + ' ' + (oy - 15) +
              'L' + (ox + 16) + ' ' + (oy + 12) +
              'L' + (ox - 16) + ' ' + (oy + 12) + 'Z',
        color: col, style: 'stroke', strokeWidth: 2.5,
      }));
      labels.push(h(Text, {
        key: 'lt' + k,
        style: [styles.signText, { top: oy - 3, color: col }],
      }, ov.text || '!'));
    } else if (ov.kind === 'sign-circle') {
      var r = Math.min(W, H) * 0.075;
      children.push(h(Skia.Circle, {
        key: 'o' + k, cx: ox, cy: oy, r: r,
        color: col, style: 'stroke', strokeWidth: 2.5,
      }));
      labels.push(h(Text, {
        key: 'lc' + k,
        style: [styles.signText, { top: oy - r * 0.55, fontSize: r * 0.9, color: col }],
      }, ov.text || ''));
    } else if (ov.kind === 'sign-arrow') {
      children.push(h(Path, {
        key: 'o' + k,
        path: 'M' + (ox - 20) + ' ' + oy + 'L' + (ox + 16) + ' ' + oy +
              'M' + (ox + 16) + ' ' + oy + 'L' + (ox + 6) + ' ' + (oy - 9) +
              'M' + (ox + 16) + ' ' + oy + 'L' + (ox + 6) + ' ' + (oy + 9),
        color: col, style: 'stroke', strokeWidth: 3,
      }));
    } else if (ov.kind === 'sign-x') {
      children.push(h(Path, {
        key: 'o' + k,
        path: 'M' + (ox - 11) + ' ' + (oy - 11) + 'L' + (ox + 11) + ' ' + (oy + 11) +
              'M' + (ox + 11) + ' ' + (oy - 11) + 'L' + (ox - 11) + ' ' + (oy + 11),
        color: col, style: 'stroke', strokeWidth: 3.5,
      }));
    }
  }

  return h(
    View,
    { style: [{ width: W, height: H, backgroundColor: theme.bg, borderRadius: 8, overflow: 'hidden' }, props.style] },
    h(Canvas, { style: { width: W, height: H } }, children),
    labels
  );
}

function starPath(x, y, r) {
  var d = '';
  for (var i = 0; i < 10; i++) {
    var rad = i % 2 === 0 ? r : r * 0.45;
    var a = (i / 10) * Math.PI * 2 - Math.PI / 2;
    var px = (x + Math.cos(a) * rad).toFixed(1), py = (y + Math.sin(a) * rad).toFixed(1);
    d += (i === 0 ? 'M' : 'L') + px + ' ' + py;
  }
  return d + 'Z';
}

function toneColor(theme, tone, a) {
  var c = tone === 'danger' ? (theme.danger || [255, 92, 96])
    : tone === 'warn' ? (theme.warn || [255, 190, 80])
    : tone === 'neutral' ? theme.grid
    : theme.glow;
  return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
}

var styles = StyleSheet.create({
  label: {
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 13,
    letterSpacing: 1,
  },
  banner: {
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 16,
    letterSpacing: 1,
  },
  poiLabel: {
    position: 'absolute',
    width: 80,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 9,
    opacity: 0.9,
  },
  laneNum: {
    position: 'absolute',
    width: 40,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 14,
    textShadowColor: 'rgba(10,14,17,0.95)',
    textShadowRadius: 3,
    textShadowOffset: { width: 0, height: 0 },
  },
  score: {
    position: 'absolute',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 13,
  },
  queue: {
    position: 'absolute',
    right: 8,
    textAlign: 'right',
    fontFamily: 'monospace',
    fontSize: 10,
  },
  subline: {
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontSize: 10,
  },
  laneLabel: {
    position: 'absolute',
    width: 60,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 11,
    lineHeight: 13,
  },
  signText: {
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    fontFamily: 'monospace',
    fontWeight: 'bold',
    fontSize: 14,
  },
  fallback: {
    backgroundColor: '#141a21',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    padding: 16,
  },
  fallbackText: { color: '#46e6aa', fontFamily: 'monospace', textAlign: 'center' },
});
