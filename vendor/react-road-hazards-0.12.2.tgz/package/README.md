# react-road-hazards

Synthwave-style 3D wireframe road-hazard animations for **React (web)** and **React Native**.
A gray perspective grid scrolls toward the viewer like a driving view; hazards deform the
mesh and glow green. 18 built-in scenes with customizable warning signs and text.

Works with zero build step: plain JS, no JSX in the published files.

## Scenes

`speed-breaker`, `slow-down`, `intersection`, `bumpy-ride`, `undulation`, `rough-road`,
`small-pothole`, `big-pothole`, `broken-road`, `crack-road`, `diversion`, `checkpost`,
`accident`, `road-crossing`, `school-area`, `speed-limit`, `curve-road`,
`multiple-speed-breakers`, `lane-quality`

## New in 0.12 — Route-event mapping mechanism (GeoJSON → HUD)

The complete pipeline between the hero/mapper system and the driver HUD:

```js
import { buildRouteEvents, createRoute } from 'react-road-hazards';

const out = buildRouteEvents(routeGeoJSON, detectionsGeoJSON, {
  lanes: 4, laneWidthM: 3.5, laneConfig: { overtaking: 'right' },
});
// out.events   -> km-mapped, fused, confidence-scored events
// out.routeDef -> createRoute()-ready (path + events together)
// out.rejected -> detections too far off-route (GPS glitches)
// out.stats    -> { detections, mapped, rejected, events, routeLengthM }

const route = createRoute(out.routeDef);   // feed the HUD; done.
```

- **Inputs**: route = GeoJSON LineString (the corridor centerline your mapper
  records); detections = GeoJSON Points with properties `type`,
  `severity` **or** `depth_mm` (LiDAR depth → severity), `timestamp`,
  optional `lane` / `note`.
- **Map-matching**: every point is projected to route chainage; lateral
  offset derives the lane; points beyond 30 m are rejected as glitches.
- **Multi-pass fusion**: repeat observations of the same physical defect
  (same type, within ~10 m, same lane) collapse to one event —
  `observations` count drives `confidence` (3+ high / 2 med / 1 low),
  severity is the max seen, `verifiedAt` is the freshest scan. A string of
  points spanning >12 m becomes one extended event with `length`.
- Lower-level pieces exported for custom pipelines: `routeFromGeoJSON`,
  `detectionsFromGeoJSON`, `mapDetectionsToRoute`, `fuseDetections`.

Pair it with the **RoadIntel Admin** page (see the admin artifact): load the
scan GeoJSONs, inspect events on the corridor map, click-to-add manual
events, edit type/lane/severity/chainage, watch the live HUD preview react,
and export the final events JSON for the driver app.

## New in 0.11 — Traffic simulation

`environment.traffic` is now a behavioral simulation, not decoration:

- **Individual speeds**: slower vehicles you gradually overtake; every third
  vehicle is faster and passes you — using the overtaking lane, per the lane
  discipline model.
- **Cars and buses** (distinct silhouettes), smooth occasional lane changes
  across cruising lanes.
- **Brake lights**: a vehicle approaching a mapped hazard zone flares a red
  flickering brake bar across its rear — the driver sees traffic reacting to
  a hazard *before* their own warning triggers.
- **Density**: `traffic: 'light' | true | 'heavy'` (3 / 5 / 8 vehicles).
- **`driveInfo.traffic`**: sorted list of vehicles ahead —
  `{ distance, lane, overtaking, braking, kind }` — for external panels or
  for cross-checking against camera detections.

## New in 0.10 — Live camera detections (dynamic boxes)

The real-time sensing layer: feed your onboard camera AI's output and each
detection renders as a pulsing wireframe box at its detected position, with a
type + distance + confidence label — visually distinct from the (static) map
data:

```jsx
<RoadHazardView mode="drive" route={route} progress={m}
  detections={[
    { id: 'd1', type: 'vehicle',    lane: 1,      distance: 45, confidence: 0.91 },
    { id: 'd2', type: 'pedestrian', lateral: -3.2, distance: 28, confidence: 0.77 },
    { id: 'd3', type: 'obstacle',   lane: 2,      distance: 60, label: 'STOPPED VEH' },
  ]} />
```

- Types: `vehicle` (green), `pedestrian` / `animal` (amber), `obstacle` /
  `pothole-live` (red) — see the `DETECTION_TYPES` export; unknown types fall
  back to obstacle. `label` overrides the display name.
- Position by `lane` index **or** `lateral` meters from the road center
  (whichever your model outputs); real-world `width`/`height` in meters
  optional. Confidence scales brightness.
- Boxes pulse to read as "live"; toggles: `show={{ detections: false }}`
  (boxes) and `show={{ detLabels: false }}` (labels). Echoed in
  `onDriveInfo(d => d.detections)`.
- Camera streams are ~10 Hz and jittery — smooth between frames before
  passing (lerp distance/lateral ~0.25/frame; the demo shows the pattern).
- This is also the exoneration input: a `STOPPED VEH` detection at a hard-
  brake site is exactly what feeds `externalIds` to the compliance tracker.

## New in 0.9.2 — EXTREME grid density + near-field row packing

`EXTREME_QUALITY` (69×92 @ 0.44 step, ~13k segments, ~7 ms/frame) plus a new
`gamma` option on quality presets: `gamma > 1` packs grid rows toward the
viewer, where the eye actually resolves them — far rows are perspective-
compressed anyway — so perceived density rises much faster than segment
count. EXTREME ships with `gamma: 1.3`; add `gamma` to any custom
`{cols, rows, step}` preset. Presets now: `LOW`, `DEFAULT`, `HIGH`, `ULTRA`,
`EXTREME`.

## New in 0.9.1 — Road types: 1 to 6 lanes

The road itself now reconfigures from single-lane village roads to 6-lane
highways — pass `lanes={1..6}` (per route, or override live per section as
carriageway width changes along the corridor):

- The grid widens symmetrically for 5-6 lanes; mountains, poles, railings,
  buildings and POIs all move outward with the road edge.
- Advisory adapts to width: below 3 lanes there is no overtaking exclusion;
  a 1-lane road yields a single PRIMARY (speed advice only); 3+ lanes exclude
  the overtaking lane as before.
- Events whose `lane` index exceeds the current width are clamped onto the
  road (a lane-3 pothole on a 2-lane stretch lands in the outermost lane).
- `createGpsTracker(route, { lanes, laneWidthM })` accepts overrides so the
  GPS lane guess follows the active road type.

## New in 0.9 — Geolocation: real GPS → route chainage

Give `createRoute` the corridor centerline as a GPS polyline (what your
mapper produces) and everything positions itself from real lat/lng:

```js
const route = createRoute({
  path: [{ lat: 22.7201, lng: 75.8503 }, ...],  // driving order
  laneWidthM: 3.5,
  lanes: 4,
  events: [...], pois: [...],
});

route.matchProgress(lat, lng)
// -> { progress, offset, distance, laneGuess, onRoute }
//    progress  = chainage meters (feed straight into the HUD)
//    offset    = signed lateral meters (+ = right of centerline)
//    laneGuess = lane index estimated from the offset
//    onRoute   = within 30 m of the corridor
```

For live tracking use the smoothing tracker — it rejects outliers (a single
220 m GPS glitch is ignored; two consistent far fixes = real relocation),
gates on reported accuracy, dead-reckons through dropouts using speed, and
stays monotonic:

```js
import { createGpsTracker } from 'react-road-hazards';
const gps = createGpsTracker(route);

// Web
navigator.geolocation.watchPosition((p) => {
  const s = gps.push({
    lat: p.coords.latitude, lng: p.coords.longitude,
    accuracy: p.coords.accuracy, speed: p.coords.speed,
    timestamp: p.timestamp,
  });
  setProgress(s.progress);                       // -> RoadHazardView
  compliance.update({ progress: s.progress, speed: s.speedKmh, ... });
}, null, { enableHighAccuracy: true });

// React Native (expo-location)
Location.watchPositionAsync(
  { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 500 },
  (p) => gps.push({ lat: p.coords.latitude, lng: p.coords.longitude,
                    accuracy: p.coords.accuracy, speed: p.coords.speed,
                    timestamp: p.timestamp })
);
```

Measured in tests: 0.0 m chainage error on the centerline, correct
lane-from-offset for all lanes at 3.5 m widths, off-route flagged at ~30 m,
and worst tracking error 3.2 m through ±4 m noise + outlier + 6-fix dropout.
The GPS `laneGuess` is a useful cross-check against your camera lane-ID
(GPS lateral accuracy alone is usually not lane-precise — treat camera as
primary, GPS as corroboration). Low-level helpers are exported too:
`haversineM`, `buildPath`, `matchToPath`, `laneFromOffset`.

## New in 0.8.1 — POI flags + driver lane choice

- Every POI now flies a **tall waving flag** visible far before the structure
  resolves: **yellow** = petrol pump, **green** = rest stop, **red** =
  mechanic. Labels match the flag color. `wireFlag` is exported and available
  in the `environment.custom` toolkit (`g.flag(x, z, poleH, tone, lvl, wave)`).
- **`driverLane`** prop: the driver's own/chosen lane (0-indexed). Renders a
  YOU marker (triangle + label) at the bottom of that lane and surfaces as
  `driveInfo.driverLane`. Toggle with `show={{ youMarker: false }}`. Feed it
  from your camera lane-ID in production, or from a lane selector UI — the
  compliance tracker's lane check then judges the actual position.

## New in 0.8 — POIs, railings, dense buildings, custom 3D objects

Any 3D object can be composed from the exported wire primitives —
`wireBox`, `wirePyramid`, `wireNgon` (wheels/rings), `wireSign` — and the
built-in structures are just compositions of them.

- **POIs on the route** (drive mode): petrol pump (canopy on columns, two
  pump units, price sign), rest stop (building + bathroom annex + food-stall
  canopy), mechanic shop (open-front garage, slanted roof, leaning spare
  tires). Declare them in `createRoute`:

  ```js
  pois: [
    { type: 'petrol-pump', at: 550,  side: 'right' },
    { type: 'rest-stop',   at: 1000, side: 'left'  },
    { type: 'mechanic',    at: 1420, side: 'right' },
  ]
  ```

  Each renders a floating name label (`show={{ poiLabels: false }}` to hide)
  and surfaces in `onDriveInfo(d => d.amenities)` as
  `{ name, distance, side }` for external "amenities ahead" panels.

- **Side railings**: `environment={{ railings: true }}` — guardrail posts +
  two horizontal rails along both road edges.
- **Dense buildings**: `environment={{ buildings: 'dense' }}` — tighter
  spacing, taller variance, and a second row of blocks for a city feel
  (`true` keeps the sparse roadside look).
- **Custom 3D objects**: `environment={{ custom: (g) => { ... } }}` gives you
  `g.line3 / g.box / g.pyramid / g.ngon / g.sign` plus `g.mToZ(meters)`,
  `g.halfW`, `g.zNear/zFar`, `g.progress`, `g.frame` — place anything at any
  chainage (water tanks, temples, toll booths, hoardings…).

## New in 0.7 — Lane numbers, denser grid, higher warning placement

- Warning sign + banner moved toward the top of the view (sign y≈0.10,
  banner y≈0.23) so the road stays unobstructed.
- **Lane numbers**: `L1..Ln` painted on each lane's road surface (projected
  onto the ground near the driver, colored by role) and prefixed in the
  bottom lane labels (`L3 · 88%`). Toggle with `show={{ laneNumbers: false }}`.
- **`ULTRA_QUALITY`** preset (55×74 grid at 0.55 step, ~8k segments) for an
  even denser wireframe.
- Every in-canvas element is now individually toggleable via `show` —
  `banner, signs, sublines, policy, queue, score, rqi, laneLabels,
  laneNumbers` — plus `advise` (chevrons/X marks), `poles`, and
  `environment`, so a driver-preferences panel can switch any of them
  on or off live.

## New in 0.6.1 — Clean canvas + external info components

The animation box can now be a pure driving view, with score and info rendered
in your own components outside it:

```jsx
<RoadHazardView mode="drive" route={route} progress={m}
  showUpcoming={3}
  show={{ score: false, rqi: false, queue: false, policy: false, laneLabels: false }}
  onDriveInfo={(d) => setInfo(d)} />

// d.policyText     -> lane policy sentence
// d.laneInfo       -> [{ lane, score, role, roleShort, tone }]  (Figure-5 bars)
// d.nextEvent, d.distance, d.passing, d.slowTo
// d.upcoming       -> [{ name, distance, tone, passing, event }]
```

`show` keys (all default true): `signs`, `banner`, `sublines`, `policy`,
`queue`, `score`, `rqi`, `laneLabels`. The compliance score itself already
lives outside the renderer (your tracker), so external panels need no extra
plumbing.

## New in 0.6 — Captain Score compliance loop + HUD polish

The closing loop from the RoadIntel spec: OBD speed + IMU + camera lane-ID
feed a per-event compliance evaluation, producing the driver's trip score.

```jsx
import { createComplianceTracker } from 'react-road-hazards';

const tracker = createComplianceTracker(route, {
  onResult: (r) => {
    if (r.celebrate) setCelebrate({ id: r.id, text: r.name + ' HANDLED' });
  },
});

// every telemetry tick:
tracker.update({
  progress,               // GPS meters
  speed,                  // km/h from OBD
  lane,                   // camera lane-ID (AI), null if unknown
  vertG,                  // IMU peak vertical g since last sample
  harshBrake, rash,       // IMU-detected behaviour flags
  externalIds: ['e5'],    // events verified externally-caused by onboard AI
});

const s = tracker.score();
// { score, eventScore, counted, excluded, passed, demerits,
//   behaviour: { harshBrakes, rash, overspeedPct } }
```

Per-event checks (only applicable ones count): **slow** — passed the hazard
at/below the advised speed; **lane** — camera-verified the driver moved out of
the hazard's lane; **limit** — speed-limit zone respected; **smooth** — IMU
confirms no hard impact crossing the hazard. An event passes only if all its
applicable checks pass; majors (severe physical hazards) weigh 2×. General
behaviour (harsh brakes, rash maneuvers, corridor overspeed) subtracts
demerits.

**Exoneration**: events verified by camera/onboard AI as externally caused
(vehicle cut in, obstacle) are excluded from scoring — pass `externalIds` in
telemetry or call `tracker.exonerate(id, reason)` retroactively. A failure
that wasn't the driver's fault never touches the score.

HUD additions (all optional props on `RoadHazardView`):

- `compliance={{ score }}` — live trip score, top-left, colored by value
- `celebrate={{ id, text }}` — change `id` to fire the winning-arrow-and-stars
  animation (~1.6 s): rising arrow, six twinkling orbiting stars, label.
  Wire it to `onResult` → `r.celebrate` for automatic firing on major
  mitigations
- `environment={{ buildings, village, traffic }}` — toggleable wireframe
  scenery: city blocks or village huts with pyramid roofs along the roadside,
  and slower vehicles ahead in the lanes that you gradually overtake

## New in 0.5 — Preloaded Route model (offline-first)

The corridor's full advisory data is preloaded once (the RoadIntel pattern:
"a few MB, cached offline") and everything at runtime is a pure function of
(route, progress) — no network, no discovery:

```jsx
import { createRoute, RoadHazardView } from 'react-road-hazards';

const route = createRoute({
  name: 'NH-52 Indore → Bhopal',
  length: 45000,
  lanes: 4,
  laneConfig: { overtaking: 'right' },
  laneSections: [                         // from mapper scans
    { from: 0,    quality: [45, 74, 88, 81] },
    { from: 8000, quality: [55, 86, 70, 84] },
  ],
  events: [ /* full corridor, preloaded */ ],
});

<RoadHazardView mode="drive" route={route} progress={gpsMeters}
  showUpcoming={3} rqi={{ score: 86, compliance: 92, harshEvents: 2 }} />
```

Route API (all offline, all derived from the preloaded data):

- `route.laneQualityAt(m)` — lane quality for any position
- `route.upcoming(m, n)` — next n events with live distances
- `route.eventsBetween(a, b)` — events overlapping a range
- `route.advisoryAt(m, prev)` — ranked lanes at any position
- `route.plan(windowM)` — **precomputed advisory windows for the whole
  corridor** (roles + policy sentence per window), with hysteresis threaded
  window-to-window. Verified property: plan output is byte-identical to what
  the live HUD computes while driving — schedule voice cues against the plan
  before departure and they can never disagree with the screen.

Also new: `showUpcoming={n}` renders a queue of the next n events (distance +
name, top-right) — since the whole route is known, the driver always sees
what's coming beyond the current warning. Same list arrives in
`onDriveInfo(info.upcoming)`.

Shared-logic exports for your cloud/voice pipeline: `effectiveLaneQuality`,
`rankLanes`, `policySentence` — the exact functions the renderer uses.

## New in 0.4 — RoadIntel advisory alignment

Implements the ranked lane advisory from the RoadIntel spec (§8.1/§8.2):

- **Ranked, not single**: every lane gets a role — `PRIMARY` (chevrons, BEST
  label), `FALLBACK` (only if within ~28% of primary), `AVOID` (red X marks on
  the road surface), `EXCLUDED` (overtaking lane — neutral gray, never
  recommended for cruising; default rightmost on 3+ lane roads, configurable
  via `laneConfig={{ overtaking: 'left' | 'right' | null }}`).
- **Stabilisers**: `minGain` (default 6 pts) + `holdMeters` (default 150)
  hysteresis — no ping-pong; instant switch only when the primary collapses
  (e.g. an accident drops it below 55). The renderer keeps this state
  automatically; if you call `computeFrame` yourself, thread
  `prevAdvisory` from the previous result.
- **Policy sentence** (voice-UX ready): `NEXT 200m: LANE 3 BEST · FALLBACK L2
  · L1 AVOID`, or `ALL LANES ROUGH — REDUCE SPEED` when even the best lane is
  bad — available as `drive.policyText` in `onDriveInfo`.
- **Severity-based slow-to** (impact ∝ speed²): auto-derived (sev ≥0.8 → 30,
  ≥0.5 → 40) or set per event via `slowTo`; shown as a banner subline with the
  event's `note` (e.g. `unmarked · slow to 30`).
- **Confidence + freshness**: per-event `confidence: 'high'` and
  `verifiedAt: 'today 05:40'` render as a subline — stale-warning trust
  management straight from the spec.
- **Trip RQI strip**: `rqi={{ score: 86, compliance: 92, harshEvents: 2 }}` →
  `TRIP RQI 86/100 · COMPLIANCE 92% · 2 HARSH` at the bottom of the view.

## New in 0.3 — DRIVE MODE (driver assistance)

Built for driver-assistance systems: feed the events from your road scan and
the vehicle's live GPS/odometer position, and the HUD does the rest.

```jsx
<RoadHazardView
  mode="drive"
  lanes={3}
  laneQuality={[58, 91, 72]}       // from your road scan
  viewDistance={200}               // meters shown ahead
  progress={vehiclePositionMeters} // update from GPS as you drive
  events={[
    { id: 'e1', type: 'pothole',      at: 320, lane: 1, severity: 0.9 },
    { id: 'e2', type: 'speed-breaker', at: 420 },
    { id: 'e3', type: 'broken-road',  at: 500, length: 60, lane: 0 },
    { id: 'e8', type: 'speed-limit',  at: 1200, value: 30 },
  ]}
  onDriveInfo={(info) => {
    // { nextEvent, distance, passing, bestLane, effQuality }
  }}
  width={400}
/>
```

How it behaves:

- An event becomes visible when it enters the `viewDistance` window (e.g.
  a pothole at 320m appears when you reach 120m — exactly 200m before the
  site) and slides toward the driver as `progress` increases.
- The banner counts down: `POTHOLE IN 190m` → `POTHOLE IN 40m` →
  `POTHOLE NOW` (blink rate increases as you approach) → gone once the GPS
  position passes the site. The next event takes over automatically.
- `ROAD CLEAR` shows when nothing is ahead in the window.
- Events can target a specific `lane` (0-indexed) or span the full road.
- Lane guidance runs continuously: events degrade their lane's *effective*
  quality (an accident in lane 3 drops it to 0), the best drivable lane is
  recomputed live, marked BEST, given flowing chevrons, and announced as
  `USE LANE n`.

Event fields: `{ id, type, at (m), lane?, length? (m), severity? (0..1),
value? (e.g. speed-limit number) }`. Types: all 17 hazard types
(`pothole`, `speed-breaker`, `multiple-speed-breakers`, `broken-road`,
`rough-road`, `bumpy-ride`, `crack-road`, `undulation`, `road-crossing`,
`school-area`, `slow-down`, `speed-limit`, `intersection`, `checkpost`,
`accident`, `diversion`, `curve-road`) — see `EVENT_TYPES` export.

### Lane differentiation (v0.3)

Lanes are now unmistakably differentiated by quality class:

- **green** lane surface = good (>= 80%), **amber** = medium (60-79%),
  **red** = poor (< 60%) — the whole lane's grid is tinted, not just a hint
- a **solid bright boundary** is drawn between adjacent lanes of different
  quality class (dashed divider when they match)
- animated **chevrons flow along the recommended lane**
- per-lane **% labels** (colored by class) + **BEST** marker + `USE LANE n`

## New in 0.2

- **Red danger channel** — severe hazards (potholes, accidents, broken road,
  speed breakers…) now glow red; informational markings stay green.
- **Electric poles** — roadside poles with sagging wires fly past for depth
  (on by default, `poles={false}` to disable).
- **Multi-lane highways** — `lanes={4}` widens the road with dashed dividers.
- **Lane quality** — `laneQuality={[55, 92, 97, 70]}` tints each lane
  (green = good, red = poor), shows a % label per lane, and marks the BEST lane.
- **`HIGH_QUALITY`** grid preset — denser wireframe for hero displays.

## Install

```bash
npm install react-road-hazards
```

React Native additionally needs Skia (used for fast wireframe rendering):

```bash
npm install @shopify/react-native-skia
cd ios && pod install   # bare RN; Expo: npx expo install @shopify/react-native-skia
```

## Usage — React (web)

```jsx
import { RoadHazardView, SCENES } from 'react-road-hazards';

export default function App() {
  return (
    <RoadHazardView
      hazard="big-pothole"
      width={400}
      height={312}
    />
  );
}
```

## Usage — React Native

Same import — Metro automatically resolves the native renderer:

```jsx
import { RoadHazardView } from 'react-road-hazards';

export default function Screen() {
  return (
    <RoadHazardView
      hazard="speed-breaker"
      width={360}
      height={280}
    />
  );
}
```

## Customizing the warning (text + sign)

Every scene has a default warning overlay. Override any part with the `warning` prop:

```jsx
// Hindi text with the default blinking triangle
<RoadHazardView
  hazard="slow-down"
  warning={{ text: 'DHEERE CHALO' }}
/>

// Custom speed limit value
<RoadHazardView
  hazard="speed-limit"
  warning={{ sign: 'circle', signText: '30', text: 'SPEED LIMIT 30' }}
/>

// Remove the sign, keep steady (non-blinking) text
<RoadHazardView
  hazard="school-area"
  warning={{ sign: 'none', text: 'CHILDREN AHEAD', blink: 0 }}
/>
```

`warning` fields (all optional — unset fields fall back to the scene default):

| Field      | Type   | Meaning                                              |
|------------|--------|------------------------------------------------------|
| `text`     | string | Label shown near the top of the view                 |
| `sign`     | string | `'triangle' \| 'circle' \| 'arrow' \| 'x' \| 'none'` |
| `signText` | string | Text inside the sign (e.g. `'!'`, `'40'`)            |
| `blink`    | number | Blink period in frames; `0` = steady                 |

## All props

| Prop      | Type            | Default              | Notes                                        |
|-----------|-----------------|----------------------|----------------------------------------------|
| `hazard`  | string          | `'speed-breaker'`    | Scene id (see list above)                    |
| `width`   | number          | `360`                | px                                           |
| `height`  | number          | `width * 0.78`       | px                                           |
| `speed`   | number          | `1`                  | Scroll speed multiplier                      |
| `warning` | object          | scene default        | See table above                              |
| `theme`   | object          | see below            | Colors                                       |
| `quality` | preset/object   | web: DEFAULT, RN: LOW| `LOW_QUALITY` / `DEFAULT_QUALITY` / `HIGH_QUALITY` or `{cols, rows, step}` |
| `lanes`   | number          | `2`                  | Highway lane count (adds dashed dividers)    |
| `laneQuality` | number[]    | —                    | 0–100 per lane; tints lanes + % labels       |
| `poles`   | boolean         | `true`               | Roadside electric poles with wires           |
| `style`   | style object    | —                    | Passed to the canvas (web) / View (native)   |

### Highway lane quality example

```jsx
import { RoadHazardView, HIGH_QUALITY } from 'react-road-hazards';

<RoadHazardView
  hazard="lane-quality"
  lanes={4}
  laneQuality={[55, 92, 97, 70]}
  quality={HIGH_QUALITY}
  width={420}
/>
```

`warning.tone` (`'danger'` red / `'accent'` green) also controls the sign color:

```jsx
<RoadHazardView hazard="slow-down" warning={{ text: 'DHEERE CHALO', tone: 'danger' }} />
```

Theme shape (any subset):

```js
{
  bg: '#141a21',          // background
  grid: [120, 132, 142],  // gray wireframe RGB
  glow: [70, 235, 175],   // green hazard RGB
  danger: [255, 92, 96],  // red warning RGB
}
```

## Cycling through scenes

```jsx
import { RoadHazardView, SCENES } from 'react-road-hazards';
import { useEffect, useState } from 'react';

function AutoCycle() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI(v => (v + 1) % SCENES.length), 6000);
    return () => clearInterval(t);
  }, []);
  return <RoadHazardView hazard={SCENES[i].id} width={360} />;
}
```

## Advanced: use the engine directly

`computeFrame()` is pure and platform-free — it returns batched line segments and
overlay commands, so you can render into any target (SVG, WebGL, headless…):

```js
import { computeFrame, segColor } from 'react-road-hazards';

const { paths, overlays } = computeFrame({
  sceneId: 'curve-road',
  frame: 120,
  width: 400,
  height: 312,
});
// paths: [{ glow, fade, points: [x1,y1,x2,y2, ...] }]
```

## Publishing (for package maintainers)

```bash
# 1. Pick your name — check availability first
npm search react-road-hazards

# 2. Update package.json: name (or scope it @yourname/road-hazards),
#    version, author, repository

# 3. Log in and publish
npm login
npm publish --access public
```

To use it locally without publishing:

```bash
# In this package folder
npm pack                     # creates react-road-hazards-0.1.0.tgz

# In your app
npm install ../path/to/react-road-hazards-0.1.0.tgz
```

Or with a monorepo / direct path: `"react-road-hazards": "file:../react-road-hazards"`.

## Performance notes (React Native)

- The native renderer defaults to a lighter 23×30 grid; pass
  `quality={{ cols: 29, rows: 40 }}` for full density on fast devices.
- Segments are batched into ~18 Skia `Path` draws per frame, so the JS-side
  math is the main cost. Reduce `quality` further for low-end devices.

## License

MIT
