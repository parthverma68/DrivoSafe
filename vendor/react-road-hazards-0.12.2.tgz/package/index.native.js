/* React Native entry (Metro picks this automatically) */
export { default as RoadHazardView } from './src/native/RoadHazardView.js';
export { SCENES, getScene } from './src/core/scenes.js';
export { computeFrame, segColor, bucketColor, DEFAULT_THEME, DEFAULT_QUALITY, LOW_QUALITY, HIGH_QUALITY, ULTRA_QUALITY, EXTREME_QUALITY } from './src/core/engine.js';
export { EVENT_TYPES, getEventType } from './src/core/events.js';
export { createRoute } from './src/core/route.js';
export { createComplianceTracker } from './src/core/compliance.js';
export { wireBox, wirePyramid, wireNgon, wireSign, wireFlag, drawPOI, POI_TYPES } from './src/core/geometry.js';
export { DETECTION_TYPES } from './src/core/engine.js';
export { routeFromGeoJSON, detectionsFromGeoJSON, mapDetectionsToRoute, fuseDetections, buildRouteEvents } from './src/core/mapper.js';
export { haversineM, buildPath, matchToPath, laneFromOffset, createGpsTracker } from './src/core/geo.js';
export { effectiveLaneQuality, rankLanes, policySentence } from './src/core/advisory.js';
