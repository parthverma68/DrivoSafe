/* Shared advisory logic (v0.5).
 * Used by BOTH the per-frame engine and route.plan() pre-computation,
 * so the live HUD and any precomputed / voice-scheduled advisory can
 * never disagree.
 */
import { getEventType } from './events.js';

/* Apply event penalties to base lane quality for position m.
 * Events within [m - grace, m + lookahead] degrade their lane's
 * effective quality (an accident in a lane drops it toward 0). */
export function effectiveLaneQuality(baseQ, lanes, events, m, lookahead) {
  var effQ = [];
  for (var li = 0; li < lanes; li++) effQ[li] = baseQ && baseQ[li] != null ? baseQ[li] : 75;
  if (!events) return effQ;
  var look = lookahead != null ? lookahead : 160;
  for (var e = 0; e < events.length; e++) {
    var ev = events[e];
    var T = getEventType(ev.type);
    var len = ev.length != null ? ev.length : T.len;
    if (ev.at + len < m - 5) continue;      // passed
    if (ev.at > m + look) continue;         // beyond advice window
    if (!T.lanePenalty) continue;
    var sev = ev.severity != null ? ev.severity : 0.7;
    var pen = T.lanePenalty * (0.5 + sev);
    if (ev.lane != null && !T.fullWidth) {
      var evL = Math.min(ev.lane, lanes - 1);
      effQ[evL] = Math.max(0, effQ[evL] - pen);
    } else if (!T.fullWidth) {
      var mid = (lanes - 1) / 2;
      for (var li2 = 0; li2 < lanes; li2++)
        if (Math.abs(li2 - mid) <= 1) effQ[li2] = Math.max(0, effQ[li2] - pen * 0.7);
    }
  }
  return effQ;
}

/* Ranked lane advisory (RoadIntel §8.1) with min-gain + hold stabilisers.
 * prev = previous advisory (for hysteresis threading), m = position meters. */
export function rankLanes(effQ, lanes, laneCfg, prev, m) {
  laneCfg = laneCfg || {};
  var overtakingLane = -1;
  if (lanes >= 3 && laneCfg.overtaking !== null) {
    if (laneCfg.overtaking === 'left') overtakingLane = 0;
    else overtakingLane = lanes - 1; // 'right' or default
  }
  var minGain = laneCfg.minGain != null ? laneCfg.minGain : 6;
  var holdM = laneCfg.holdMeters != null ? laneCfg.holdMeters : 150;
  var fbBand = laneCfg.fallbackBand != null ? laneCfg.fallbackBand : 0.28;

  var eligible = [];
  for (var lr = 0; lr < lanes; lr++) if (lr !== overtakingLane) eligible.push(lr);
  var rawBest = eligible[0];
  for (var lb = 1; lb < eligible.length; lb++)
    if (effQ[eligible[lb]] > effQ[rawBest]) rawBest = eligible[lb];

  var primary = rawBest, switchedAt = m || 0;
  if (prev && prev.primary != null && prev.primary !== rawBest &&
      prev.primary !== overtakingLane && prev.primary < lanes) {
    var prevScore = effQ[prev.primary];
    var held = (m || 0) - (prev.switchedAt || 0);
    var collapsed = prevScore < 55;
    if (!collapsed && (effQ[rawBest] - prevScore < minGain || held < holdM)) {
      primary = prev.primary;
      switchedAt = prev.switchedAt || 0;
    }
  } else if (prev && prev.primary === primary) {
    switchedAt = prev.switchedAt || 0;
  }

  var fallback = -1;
  for (var lf = 0; lf < eligible.length; lf++) {
    var cand = eligible[lf];
    if (cand === primary) continue;
    if (effQ[cand] >= effQ[primary] * (1 - fbBand)) {
      if (fallback === -1 || effQ[cand] > effQ[fallback]) fallback = cand;
    }
  }
  var reduceSpeed = effQ[primary] < 60;
  var roles = [];
  for (var lo = 0; lo < lanes; lo++) {
    if (lo === overtakingLane) roles.push('EXCLUDED');
    else if (lo === primary) roles.push('PRIMARY');
    else if (lo === fallback) roles.push('FALLBACK');
    else if (effQ[lo] < 60 || effQ[lo] < effQ[primary] * (1 - fbBand)) roles.push('AVOID');
    else roles.push('OK');
  }
  return {
    roles: roles, primary: primary, fallback: fallback,
    reduceSpeed: reduceSpeed, switchedAt: switchedAt, scores: effQ.slice(),
  };
}

/* One-sentence policy for a window (voice-UX ready) */
export function policySentence(advisory, windowM) {
  var wTxt = windowM >= 1000 ? (windowM / 1000) + 'km' : windowM + 'm';
  if (advisory.reduceSpeed) return 'ALL LANES ROUGH \u2014 REDUCE SPEED';
  var policy = 'NEXT ' + wTxt + ': LANE ' + (advisory.primary + 1) + ' BEST';
  if (advisory.fallback >= 0) policy += ' \u00b7 FALLBACK L' + (advisory.fallback + 1);
  var avoids = [];
  for (var av = 0; av < advisory.roles.length; av++)
    if (advisory.roles[av] === 'AVOID') avoids.push('L' + (av + 1));
  if (avoids.length) policy += ' \u00b7 ' + avoids.join(',') + ' AVOID';
  return policy;
}
