/* Driver Compliance Tracker (v0.6) — the Captain Score closing loop.
 *
 * Feed it telemetry every frame (or every GPS tick):
 *   tracker.update({
 *     progress,      // meters (GPS/odometer)
 *     speed,         // km/h from OBD
 *     lane,          // current lane index from camera AI (null if unknown)
 *     vertG,         // peak vertical accel since last sample (g) from IMU
 *     harshBrake,    // IMU-detected harsh braking this sample
 *     rash,          // IMU-detected rash maneuver this sample
 *     externalIds,   // event ids verified by camera/AI as externally caused
 *   })
 *
 * For every route event it evaluates the applicable checks:
 *   slow   - did the driver pass the hazard at/below the advised speed?
 *   lane   - did the driver move out of the hazard's lane (camera lane-ID)?
 *   limit  - was the speed-limit zone respected?
 *   smooth - IMU: was the hazard crossed without a hard impact?
 *
 * Events flagged as externally caused (another vehicle cutting in, obstacle
 * reported by onboard AI) are EXCLUDED from scoring — failures that weren't
 * the driver's fault never count against them.
 *
 * Results stream out via onResult(result); result.celebrate is true when a
 * MAJOR hazard was fully mitigated (the HUD's winning-arrow moment).
 */
import { getEventType } from './events.js';

var PHYSICAL = {
  'pothole': 1, 'speed-breaker': 1, 'multiple-speed-breakers': 1,
  'broken-road': 1, 'rough-road': 1, 'bumpy-ride': 1, 'crack-road': 1,
  'undulation': 1,
};

function derivedSlowTo(ev, T) {
  if (ev.slowTo != null) return ev.slowTo;
  var sev = ev.severity != null ? ev.severity : 0.7;
  if (T.tone === 'danger') return sev >= 0.8 ? 30 : sev >= 0.5 ? 40 : 50;
  return null;
}

export function createComplianceTracker(route, cfg) {
  cfg = cfg || {};
  var approachM = cfg.approachMeters != null ? cfg.approachMeters : 120;
  var speedTol = cfg.speedTolerance != null ? cfg.speedTolerance : 6;   // km/h
  var gLimit = cfg.impactGLimit != null ? cfg.impactGLimit : 0.35;      // g
  var corridorLimit = cfg.corridorSpeedLimit != null ? cfg.corridorSpeedLimit : 80;
  var onResult = cfg.onResult || function () {};

  var recs = {};        // eventId -> tracking record
  var results = [];     // completed evaluations
  var behaviour = { harshBrakes: 0, rash: 0, overspeedSamples: 0, samples: 0 };
  var exonerated = {};  // id -> reason

  function recFor(ev) {
    var r = recs[ev.id];
    if (!r) {
      r = recs[ev.id] = {
        ev: ev, T: getEventType(ev.type),
        maxSpeedPassage: 0, minSpeedApproach: 1e9,
        maxVertG: 0, laneCounts: {}, laneSamples: 0,
        done: false,
      };
      r.len = ev.length != null ? ev.length : r.T.len;
    }
    return r;
  }

  function evaluate(r) {
    var ev = r.ev, T = r.T;
    var sev = ev.severity != null ? ev.severity : 0.7;
    var checks = {};

    var slowTo = derivedSlowTo(ev, T);
    if (slowTo != null && PHYSICAL[ev.type]) {
      checks.slow = r.maxSpeedPassage <= slowTo + speedTol;
    }
    if (ev.lane != null && !T.fullWidth && r.laneSamples > 0) {
      // camera lane-ID: dominant lane during passage must not be the hazard lane
      var dom = null, domN = -1;
      for (var k in r.laneCounts) if (r.laneCounts[k] > domN) { domN = r.laneCounts[k]; dom = Number(k); }
      checks.lane = dom !== ev.lane;
    }
    if (ev.type === 'speed-limit') {
      checks.limit = r.maxSpeedPassage <= (ev.value != null ? ev.value : 40) + 3;
    }
    if (PHYSICAL[ev.type]) {
      checks.smooth = r.maxVertG <= gLimit;
    }

    var applicable = 0, passedN = 0;
    for (var c in checks) { applicable++; if (checks[c]) passedN++; }
    var passed = applicable > 0 && passedN === applicable;
    // "major" = a physical hazard worth celebrating when fully mitigated
    var major = !!PHYSICAL[ev.type] && (sev >= 0.7 || T.lanePenalty >= 40);
    var excluded = !!exonerated[ev.id];

    var result = {
      id: ev.id, type: ev.type, name: T.name, at: ev.at,
      checks: checks, applicable: applicable,
      passed: passed, major: major,
      excluded: excluded, excludeReason: exonerated[ev.id] || null,
      celebrate: passed && major && !excluded,
      maxSpeed: Math.round(r.maxSpeedPassage),
      maxVertG: Math.round(r.maxVertG * 100) / 100,
      slowTo: slowTo,
    };
    results.push(result);
    onResult(result);
    return result;
  }

  function update(s) {
    behaviour.samples++;
    if (s.harshBrake) behaviour.harshBrakes++;
    if (s.rash) behaviour.rash++;
    if (s.speed > corridorLimit + speedTol) behaviour.overspeedSamples++;
    if (s.externalIds) {
      for (var x = 0; x < s.externalIds.length; x++) {
        if (!exonerated[s.externalIds[x]]) exonerated[s.externalIds[x]] = 'external cause (verified)';
      }
    }

    var m = s.progress;
    var evs = route.events;
    for (var i = 0; i < evs.length; i++) {
      var ev = evs[i];
      if (ev.at - approachM > m) break;            // sorted: rest are ahead
      var T = getEventType(ev.type);
      var len = ev.length != null ? ev.length : T.len;
      if (recs[ev.id] && recs[ev.id].done) continue;
      if (ev.at + len + 15 < m) {
        // event fully passed: finalize
        if (recs[ev.id]) { recs[ev.id].done = true; evaluate(recs[ev.id]); }
        else { var r0 = recFor(ev); r0.done = true; evaluate(r0); }
        continue;
      }
      var r = recFor(ev);
      if (m >= ev.at - approachM && m < ev.at) {
        if (s.speed < r.minSpeedApproach) r.minSpeedApproach = s.speed;
      }
      if (m >= ev.at && m <= ev.at + len) {
        if (s.speed > r.maxSpeedPassage) r.maxSpeedPassage = s.speed;
        if (s.vertG != null && s.vertG > r.maxVertG) r.maxVertG = s.vertG;
        if (s.lane != null) {
          r.laneCounts[s.lane] = (r.laneCounts[s.lane] || 0) + 1;
          r.laneSamples++;
        }
      }
    }
  }

  function exonerate(id, reason) {
    exonerated[id] = reason || 'external cause (verified)';
    // retro-apply to an already-emitted result
    for (var i = 0; i < results.length; i++) {
      if (results[i].id === id) {
        results[i].excluded = true;
        results[i].excludeReason = exonerated[id];
      }
    }
  }

  function score() {
    var wTot = 0, wPass = 0, counted = 0;
    for (var i = 0; i < results.length; i++) {
      var r = results[i];
      if (r.excluded || r.applicable === 0) continue;
      var w = r.major ? 2 : 1;
      wTot += w;
      if (r.passed) wPass += w;
      counted++;
    }
    var eventScore = wTot > 0 ? (wPass / wTot) * 100 : 100;
    var overspeedFrac = behaviour.samples ? behaviour.overspeedSamples / behaviour.samples : 0;
    var demerits = behaviour.harshBrakes * 2 + behaviour.rash * 4 + overspeedFrac * 20;
    var final = Math.max(0, Math.min(100, Math.round(eventScore - demerits)));
    return {
      score: final,
      eventScore: Math.round(eventScore),
      counted: counted,
      excluded: results.length - counted,
      passed: results.filter(function (r) { return !r.excluded && r.passed; }).length,
      demerits: Math.round(demerits),
      behaviour: {
        harshBrakes: behaviour.harshBrakes,
        rash: behaviour.rash,
        overspeedPct: Math.round(overspeedFrac * 100),
      },
    };
  }

  return {
    update: update,
    exonerate: exonerate,
    score: score,
    results: results,
    reset: function () { recs = {}; results.length = 0; exonerated = {}; behaviour = { harshBrakes: 0, rash: 0, overspeedSamples: 0, samples: 0 }; },
  };
}
