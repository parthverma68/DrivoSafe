/* Platform-agnostic frame engine (v0.4 — RoadIntel-aligned).
 *
 * v0.4 implements the RoadIntel advisory spec (report v3.2 §8):
 *  - RANKED lane advisory: PRIMARY / FALLBACK / AVOID / EXCLUDED
 *    (overtaking lane never recommended for cruising; truck lane eligible
 *    but expected worst). Fallback only within ~28% of primary, otherwise
 *    the advice becomes REDUCE SPEED, not a dressed-up bad lane.
 *  - Stabilisers: minimum-gain threshold + hold distance (no ping-pong).
 *  - Severity-based slow-to speeds, confidence + freshness sublines.
 *  - Trip RQI strip (score / compliance / harsh events).
 */
/* Platform-agnostic frame engine (v0.3).
 *
 * TWO MODES:
 *  - loop  (default): the original self-running scene animations
 *  - drive : driver-assistance mode. The view is a window onto a scanned
 *            route. You feed `events` (from your map scan) and `progress`
 *            (current odometer/GPS meters). Hazards appear at their true
 *            distance, slide toward the driver as progress increases, and
 *            disappear once passed. The overlay banner counts down
 *            ("POTHOLE IN 143m" -> "POTHOLE NOW") and lane guidance
 *            continuously recommends the best drivable lane.
 *
 * LANE DIFFERENTIATION (v0.3):
 *  - three-tone lanes: green (good >= 80), amber (60-79), red (< 60)
 *  - whole lane surface is tinted, transverse lines strongest
 *  - solid bright boundary between lanes of different quality class
 *  - animated chevrons flow along the recommended lane
 *  - per-lane % labels + "USE LANE n" advisory
 */
import { getScene, smoothNoise, clamp, localZ } from './scenes.js';
import { getEventType } from './events.js';
import { effectiveLaneQuality, rankLanes, policySentence } from './advisory.js';
import { wireBox, wirePyramid, wireNgon, wireSign, wireFlag, drawPOI, POI_TYPES } from './geometry.js';

/* live camera-AI detection types: rendered as pulsing wireframe boxes,
   distinct from map data (which is static until the scan updates) */
export var DETECTION_TYPES = {
  'vehicle': { name: 'VEHICLE', tone: 'glow', w: 2.2, h: 1.5, d: 2.6 },
  'pedestrian': { name: 'PERSON', tone: 'warn', w: 0.7, h: 1.75, d: 0.6 },
  'animal': { name: 'ANIMAL', tone: 'warn', w: 1.0, h: 1.2, d: 1.9 },
  'obstacle': { name: 'OBSTACLE', tone: 'danger', w: 1.6, h: 1.1, d: 1.6 },
  'pothole-live': { name: 'NEW POTHOLE', tone: 'danger', w: 1.6, h: 0.25, d: 1.6 },
};

export var DEFAULT_THEME = {
  bg: '#141a21',
  grid: [120, 132, 142],   // gray base grid
  glow: [70, 235, 175],    // green: good / informational
  warn: [255, 190, 80],    // amber: medium quality / caution
  danger: [255, 92, 96],   // red: bad / severe
  accent: '#46e6aa',
};

export var DEFAULT_QUALITY = { cols: 29, rows: 40, step: 1 };
export var LOW_QUALITY = { cols: 23, rows: 30, step: 1 };
export var HIGH_QUALITY = { cols: 45, rows: 60, step: 0.65 };
export var ULTRA_QUALITY = { cols: 55, rows: 74, step: 0.55 };
/* gamma > 1 packs rows toward the viewer (near-field density is what the
   eye sees; far rows are perspective-compressed anyway) */
export var EXTREME_QUALITY = { cols: 69, rows: 92, step: 0.44, gamma: 1.3 };

var Z_NEAR = 1.8;
var CAM_H = 5;
var LANE_W = 4;

/* color for a tone bucket */
export function bucketColor(b, theme) {
  var t = theme || DEFAULT_THEME;
  if (b.tone === 'grid' || b.level <= 0.05) {
    return 'rgba(' + t.grid[0] + ',' + t.grid[1] + ',' + t.grid[2] + ',' + (0.5 * b.fade).toFixed(3) + ')';
  }
  var target = t[b.tone] || t.glow;
  var g = clamp(b.level, 0, 1);
  var r = Math.round(t.grid[0] + (target[0] - t.grid[0]) * g);
  var gr = Math.round(t.grid[1] + (target[1] - t.grid[1]) * g);
  var bl = Math.round(t.grid[2] + (target[2] - t.grid[2]) * g);
  return 'rgba(' + r + ',' + gr + ',' + bl + ',' + ((0.5 + 0.5 * g) * b.fade).toFixed(3) + ')';
}
/* legacy helper kept for compatibility */
export function segColor(glow, fade, theme, danger) {
  var tone = (danger || 0) > (glow || 0) ? 'danger' : 'glow';
  return bucketColor({ tone: tone, level: Math.max(glow || 0, danger || 0), fade: fade }, theme);
}

function qLvl(g) { return Math.round(clamp(g, 0, 1) * 5) / 5; }
function qFade(f) { return f > 0.8 ? 1 : f > 0.45 ? 0.65 : 0.3; }
function laneClass(q) { return q >= 80 ? 'glow' : q >= 60 ? 'warn' : 'danger'; }

/**
 * computeFrame(opts) ->
 *   { paths: [{tone, level, fade, points:[...]}], overlays: [...], scene?, drive? }
 *
 * Common opts: width, height, quality, frame.
 * LOOP mode:  sceneId, speed, overlay, lanes, laneQuality, poles
 * DRIVE mode: mode:'drive', progress (m), events[], viewDistance (m, default 200),
 *             lanes, laneQuality (array 0..100 per lane), poles,
 *             advise (bool, default true: chevrons + USE LANE n)
 */
export function computeFrame(opts) {
  var overlaysDet = [];
  function overlays0detPush(arr, o) { arr.push(o); }
  var W = opts.width, H = opts.height;
  var q = opts.quality || DEFAULT_QUALITY;
  var COLS = q.cols, ROWS = q.rows, STEP = q.step || 1;
  var GAMMA = q.gamma || 1;
  var frame = opts.frame || 0;
  var drive = opts.mode === 'drive';

  var scene = drive ? null : getScene(opts.sceneId);
  /* preloaded route object resolves events / lane quality / config */
  var route = opts.route || null;
  var lanes = opts.lanes != null ? opts.lanes
    : route && route.lanes ? route.lanes
    : (scene && scene.defaultLanes) || 2;
  var laneQuality = opts.laneQuality != null ? opts.laneQuality
    : route ? route.laneQualityAt(opts.progress || 0)
    : (scene && scene.defaultLaneQuality);
  var poles = opts.poles !== false;
  var advise = opts.advise !== false;
  var halfW = (lanes * LANE_W) / 2;

  var zSpan = ROWS * STEP;
  var Z_ROWS = new Array(ROWS);
  for (var zr = 0; zr < ROWS; zr++) {
    var frac = ROWS > 1 ? zr / (ROWS - 1) : 0;
    Z_ROWS[zr] = Z_NEAR + zSpan * (GAMMA === 1 ? frac : Math.pow(frac, GAMMA));
  }
  var viewDistance = opts.viewDistance || 200;
  var mScale = zSpan / viewDistance; // world units per meter
  var progress = opts.progress || 0;

  var scroll;
  if (drive) {
    scroll = progress * mScale; // world moves with real position
  } else {
    var speed = ((scene && scene.speed) != null ? scene.speed : 0.09) * (opts.speed != null ? opts.speed : 1);
    scroll = frame * speed;
  }

  var horizon = H * 0.28;
  var K = ((H - horizon - 8) * Z_NEAR) / CAM_H;
  var KX = K * 1.35;
  var spanX = (COLS - 1) * STEP;
  if (halfW + 5 > spanX / 2) {
    // wide roads (5-6 lanes): grow the grid symmetrically
    COLS = Math.ceil((2 * (halfW + 5)) / STEP) + 1;
    spanX = (COLS - 1) * STEP;
  }
  var X0 = -spanX / 2;

  function projX(x, z) { return W / 2 + (x * KX) / z; }
  function projY(h, z) { return horizon + ((CAM_H - h) * K) / z; }
  function mToZ(m) { return Z_NEAR + (m - progress) * mScale; }

  function mountains(x, zw) {
    var m = clamp((Math.abs(x) - (halfW + 2)) / 7, 0, 1);
    return m * smoothNoise(x * 0.35, zw * 0.12) * 5.5;
  }

  /* ---- active events (drive mode) ---- */
  var active = [];
  var evAll = opts.events || (route ? route.events : []) || [];
  if (drive) {
    for (var e = 0; e < evAll.length; e++) {
      var ev = evAll[e];
      var T = getEventType(ev.type);
      var len = ev.length != null ? ev.length : T.len;
      if (ev.at + len < progress - 5) continue;                 // passed
      if (ev.at > progress + viewDistance + 10) continue;       // too far
      var laneIdx = ev.lane != null ? Math.min(ev.lane, lanes - 1) : null;
      var laneX = laneIdx != null ? -halfW + (laneIdx + 0.5) * LANE_W : 0;
      active.push({
        ev: ev, T: T, len: len, laneIdx: laneIdx,
        lenWU: Math.max(len * mScale, 1.4),
        centerM: ev.at + len / 2,
        laneX: laneX,
        sev: ev.severity != null ? ev.severity : 0.7,
      });
    }
  }

  /* lane effective quality (events degrade their lane) — shared logic */
  var effQ = null;
  if (laneQuality) {
    effQ = drive
      ? effectiveLaneQuality(laneQuality, lanes, evAll, progress, 160)
      : effectiveLaneQuality(laneQuality, lanes, null, 0, 0);
  }

  /* RANKED lane advisory (RoadIntel §8.1) — shared with route.plan() */
  var laneCfg = opts.laneConfig || (route ? route.laneConfig : {}) || {};
  var prev = opts.prevAdvisory || null;
  var advisory = null, bestLane = -1;
  if (effQ) {
    advisory = rankLanes(effQ, lanes, laneCfg, drive ? prev : null, drive ? progress : 0);
    bestLane = advisory.primary;
  }

  /* road center shift (diversion / curve events, or scene) */
  function roadCenterAt(zw) {
    if (!drive) return scene && scene.roadCenter ? scene.roadCenter(zw, frame) : 0;
    var m = (zw - Z_NEAR) / mScale;
    var s = 0;
    for (var a3 = 0; a3 < active.length; a3++) {
      var A2 = active[a3];
      if (A2.T.roadShift && m >= A2.ev.at - 5 && m <= A2.ev.at + A2.len + 5)
        s += A2.T.roadShift(m, { at: A2.ev.at, length: A2.len, severity: A2.ev.severity });
    }
    return s;
  }

  /* ---- vertex field: per-vertex tone channels g/d/w + height ---- */
  var N = COLS * ROWS;
  var VX = new Array(N), VY = new Array(N);
  var VG = new Array(N), VD = new Array(N), VW = new Array(N);
  var VSKIP = new Array(N);
  var c, r, i;

  for (c = 0; c < COLS; c++) {
    var x = X0 + c * STEP;
    for (r = 0; r < ROWS; r++) {
      var z = Z_ROWS[r];
      var zw = z + scroll;
      var cen = roadCenterAt(zw);
      var xl = x - cen;
      var h = mountains(x, zw);
      var g = 0, d = 0, w = 0, sk = false;

      if (!drive && scene) {
        if (scene.height) h += scene.height(xl, zw, frame);
        if (scene.glow) g = scene.glow(xl, zw, frame) || 0;
        if (scene.danger) d = scene.danger(xl, zw, frame) || 0;
        if (scene.skip && scene.skip(xl, zw, frame)) sk = true;
      }

      if (drive) {
        for (var a = 0; a < active.length; a++) {
          var A3 = active[a];
          var dz = zw - (Z_NEAR + A3.centerM * mScale);
          if (Math.abs(dz) > A3.lenWU / 2 + 4) continue;
          if (Math.abs(xl) > halfW + 0.6) continue; // events live on the road
          var dx = A3.T.fullWidth ? xl : xl - A3.laneX;
          if (!A3.T.fullWidth && Math.abs(dx) > LANE_W * 0.9) continue;
          if (A3.T.field) {
            var fld = A3.T.field(dx, dz, A3.lenWU, A3.sev, zw, frame);
            if (fld) {
              if (fld.h) h += fld.h;
              if (fld.g) g = Math.max(g, fld.g);
              if (fld.d) d = Math.max(d, fld.d);
              if (fld.w) w = Math.max(w, fld.w);
            }
          }
          if (A3.T.skip && A3.T.skip(dx, dz, A3.lenWU, zw)) sk = true;
        }
      }

      /* lane surface tint: strong three-tone differentiation
         (EXCLUDED overtaking lane stays neutral gray) */
      if (laneQuality && Math.abs(xl) < halfW) {
        var li4 = Math.floor((xl + halfW) / LANE_W);
        if (li4 >= 0 && li4 < lanes && !(advisory && advisory.roles[li4] === 'EXCLUDED')) {
          var qv = effQ ? effQ[li4] : laneQuality[li4];
          var cls = laneClass(qv);
          var lvl = cls === 'glow' ? 0.4 : cls === 'warn' ? 0.5 : 0.55;
          if (cls === 'glow') g = Math.max(g, lvl);
          else if (cls === 'warn') w = Math.max(w, lvl);
          else d = Math.max(d, lvl);
        }
      }

      /* road edges */
      if (Math.abs(Math.abs(xl) - halfW) < 0.5 * STEP + 0.01) g = Math.max(g, 0.6);
      /* lane boundaries: SOLID bright line when adjacent lanes differ in
         quality class, dashed subtle otherwise */
      if (lanes > 1 && Math.abs(xl) < halfW - 0.3) {
        var mod = ((xl + halfW) % LANE_W + LANE_W) % LANE_W;
        var nearDiv = mod < 0.5 * STEP + 0.01 || mod > LANE_W - 0.5 * STEP - 0.01;
        if (nearDiv) {
          var bIdx = Math.round((xl + halfW) / LANE_W);
          var diff = false;
          if (laneQuality && bIdx >= 1 && bIdx <= lanes - 1) {
            var qa = effQ ? effQ[bIdx - 1] : laneQuality[bIdx - 1];
            var qb = effQ ? effQ[bIdx] : laneQuality[bIdx];
            diff = laneClass(qa) !== laneClass(qb);
          }
          if (diff) g = Math.max(g, 0.85);
          else if (localZ(zw, 4) < 2) g = Math.max(g, 0.3);
        }
      }

      i = c * ROWS + r;
      VX[i] = projX(x, z);
      VY[i] = projY(h, z);
      VG[i] = g; VD[i] = d; VW[i] = w;
      VSKIP[i] = sk;
    }
  }

  /* ---- batch segments by dominant tone ---- */
  var buckets = {};
  function pushSeg(tone, level, fade, x1, y1, x2, y2) {
    var lq = qLvl(level), fq = qFade(fade);
    var key = tone + '_' + lq + '_' + fq;
    var b = buckets[key];
    if (!b) b = buckets[key] = { tone: tone, level: lq, fade: fq, points: [] };
    b.points.push(x1, y1, x2, y2);
  }
  function domTone(i1, i2, transverse) {
    // transverse (left-right) lines carry full lane tint; depth lines lighter
    var mul = transverse ? 1 : 0.55;
    var g = Math.max(VG[i1], VG[i2]);
    var d = Math.max(VD[i1], VD[i2]);
    var w = Math.max(VW[i1], VW[i2]) * mul;
    var gg = g > 0.55 ? g : g * mul;      // bright markings keep strength
    var dd = d > 0.6 ? d : d * mul;
    if (dd >= gg && dd >= w) return dd > 0.05 ? ['danger', dd] : ['grid', 0];
    if (w >= gg) return w > 0.05 ? ['warn', w] : ['grid', 0];
    return gg > 0.05 ? ['glow', gg] : ['grid', 0];
  }

  for (r = ROWS - 1; r >= 0; r--) {
    var fade = clamp(1.15 - r / ROWS, 0.15, 1);
    for (c = 0; c < COLS; c++) {
      i = c * ROWS + r;
      if (c < COLS - 1) {
        var i2 = (c + 1) * ROWS + r;
        if (!VSKIP[i]) {
          var t1 = domTone(i, i2, true);
          pushSeg(t1[0], t1[1], fade, VX[i], VY[i], VX[i2], VY[i2]);
        }
      }
      if (r < ROWS - 1) {
        var i3 = c * ROWS + r + 1;
        if (!VSKIP[i]) {
          var t2 = domTone(i, i3, false);
          pushSeg(t2[0], t2[1], fade, VX[i], VY[i], VX[i3], VY[i3]);
        }
      }
    }
  }

  /* ---- 3D line helper ---- */
  var zFar = Z_NEAR + zSpan;
  function line3(x1, h1, z1, x2, h2, z2, tone, level) {
    if (z1 < Z_NEAR * 0.9 || z2 < Z_NEAR * 0.9) return;
    if (z1 > zFar && z2 > zFar) return;
    pushSeg(tone, level, 1, projX(x1, z1), projY(h1, z1), projX(x2, z2), projY(h2, z2));
  }
  // legacy adapter for loop-mode scene geometry(gl, dn)
  var legacyLine3 = function (x1, h1, z1, x2, h2, z2, gl, dn) {
    if ((dn || 0) > (gl || 0)) line3(x1, h1, z1, x2, h2, z2, 'danger', dn);
    else line3(x1, h1, z1, x2, h2, z2, 'glow', gl || 0);
  };

  if (!drive && scene && scene.geometry) scene.geometry(legacyLine3, scroll, frame);

  if (drive) {
    for (var a4 = 0; a4 < active.length; a4++) {
      var A4 = active[a4];
      if (!A4.T.geometry) continue;
      var ze = mToZ(A4.centerM);
      if (ze < Z_NEAR || ze > zFar) continue;
      if (A4.T.laneGeometry) A4.T.geometry(line3, A4.laneX, ze, A4.sev, frame);
      else A4.T.geometry(line3, halfW, ze, A4.sev, frame);
    }
  }

  /* ---- advisory markings on the road surface ---- */
  if (advise && advisory) {
    // flowing chevrons along the PRIMARY lane
    var bx = -halfW + (advisory.primary + 0.5) * LANE_W;
    var chGap = 5;
    var zwFirstC = Math.ceil((scroll + Z_NEAR + 1) / chGap) * chGap;
    for (var zwc = zwFirstC; zwc < scroll + zFar * 0.8; zwc += chGap) {
      var zc = zwc - scroll;
      var pulse = 0.55 + 0.4 * Math.sin(frame * 0.12 - zc * 0.35);
      line3(bx - 1.0, 0.06, zc + 1.1, bx, 0.06, zc, 'glow', pulse);
      line3(bx + 1.0, 0.06, zc + 1.1, bx, 0.06, zc, 'glow', pulse);
    }
    // red X marks along AVOID lanes
    for (var xa = 0; xa < lanes; xa++) {
      if (advisory.roles[xa] !== 'AVOID') continue;
      var ax = -halfW + (xa + 0.5) * LANE_W;
      var zwFirstX = Math.ceil((scroll + Z_NEAR + 3) / 7) * 7;
      for (var zwx = zwFirstX; zwx < scroll + zFar * 0.7; zwx += 7) {
        var zx = zwx - scroll;
        line3(ax - 0.7, 0.06, zx + 0.8, ax + 0.7, 0.06, zx - 0.8, 'danger', 0.8);
        line3(ax + 0.7, 0.06, zx + 0.8, ax - 0.7, 0.06, zx - 0.8, 'danger', 0.8);
      }
    }
  }

  /* ---- environment scenery: buildings / village / traffic (toggleable) ---- */
  var env = opts.environment || {};
  function envBox(x, z, wdt, dep, hgt, lvl) {
    var y0 = 0;
    // base rectangle
    line3(x, y0, z, x + wdt, y0, z, 'glow', lvl);
    line3(x + wdt, y0, z, x + wdt, y0, z + dep, 'glow', lvl);
    line3(x + wdt, y0, z + dep, x, y0, z + dep, 'glow', lvl);
    line3(x, y0, z + dep, x, y0, z, 'glow', lvl);
    // top rectangle
    line3(x, hgt, z, x + wdt, hgt, z, 'glow', lvl);
    line3(x + wdt, hgt, z, x + wdt, hgt, z + dep, 'glow', lvl);
    line3(x + wdt, hgt, z + dep, x, hgt, z + dep, 'glow', lvl);
    line3(x, hgt, z + dep, x, hgt, z, 'glow', lvl);
    // pillars
    line3(x, y0, z, x, hgt, z, 'glow', lvl);
    line3(x + wdt, y0, z, x + wdt, hgt, z, 'glow', lvl);
    line3(x + wdt, y0, z + dep, x + wdt, hgt, z + dep, 'glow', lvl);
    line3(x, y0, z + dep, x, hgt, z + dep, 'glow', lvl);
  }
  /* side railings (guardrails): posts + two horizontal rails along both edges */
  if (env.railings) {
    var rGap = 3;
    var zwR0 = Math.ceil((scroll + Z_NEAR) / rGap) * rGap;
    for (var rs = -1; rs <= 1; rs += 2) {
      var rx = rs * (halfW + 0.8);
      var prevZ = null;
      for (var zwr = zwR0; zwr < scroll + zFar; zwr += rGap) {
        var zR = zwr - scroll;
        if (zR < Z_NEAR + 0.5) { prevZ = zR; continue; }
        var fadeR = clamp(1.15 - zR / zFar, 0.2, 0.7);
        line3(rx, 0, zR, rx, 0.9, zR, 'glow', fadeR * 0.5); // post
        if (prevZ != null && prevZ > Z_NEAR * 0.9) {
          line3(rx, 0.45, prevZ, rx, 0.45, zR, 'glow', fadeR * 0.45);
          line3(rx, 0.85, prevZ, rx, 0.85, zR, 'glow', fadeR * 0.45);
        }
        prevZ = zR;
      }
    }
  }

  if (env.buildings || env.village) {
    var dense = env.buildings === 'dense';
    var bGap = env.village ? 22 : dense ? 7 : 14;
    var zwB0 = Math.ceil((scroll + Z_NEAR) / bGap) * bGap;
    for (var bs = -1; bs <= 1; bs += 2) {
      for (var zwb = zwB0 + (bs > 0 ? bGap / 2 : 0); zwb < scroll + zFar; zwb += bGap) {
        var zB = zwb - scroll;
        if (zB < Z_NEAR + 1) continue;
        var seed = Math.floor(zwb) * bs;
        if (smoothNoise(seed * 0.13, 7) < (dense ? 0.1 : 0.25)) continue; // gaps
        var fadeB = clamp(1.1 - zB / zFar, 0.15, 0.6);
        var bx = bs * (halfW + 5.5 + smoothNoise(seed * 0.31, 3) * 3);
        if (env.buildings) {
          var bh = 2.2 + smoothNoise(seed * 0.17, 11) * (dense ? 6.0 : 4.2);
          envBox(bx - 1.1, zB, 2.2, 2.2, bh, fadeB * 0.55);
          if (dense) {
            // second row further out for a city-block feel
            var bx2 = bx + bs * (3.6 + smoothNoise(seed * 0.53, 5) * 2);
            var bh2 = 1.8 + smoothNoise(seed * 0.29, 13) * 5.2;
            envBox(bx2 - 1.0, zB + 1.5, 2.0, 2.0, bh2, fadeB * 0.4);
          }
        } else {
          // village hut: low box + pyramid roof
          var hh = 1.3 + smoothNoise(seed * 0.17, 11) * 0.9;
          envBox(bx - 1.0, zB, 2.0, 2.0, hh, fadeB * 0.5);
          var ax = bx, azm = zB + 1.0, apex = hh + 1.0;
          line3(bx - 1.0, hh, zB, ax, apex, azm, 'glow', fadeB * 0.5);
          line3(bx + 1.0, hh, zB, ax, apex, azm, 'glow', fadeB * 0.5);
          line3(bx - 1.0, hh, zB + 2.0, ax, apex, azm, 'glow', fadeB * 0.5);
          line3(bx + 1.0, hh, zB + 2.0, ax, apex, azm, 'glow', fadeB * 0.5);
        }
      }
    }
  }
  if (env.traffic) {
    /* traffic simulation (deterministic, stateless):
       - individual relative speeds: slow vehicles you overtake, fast ones
         that pass you using the overtaking lane
       - cars and buses, smooth lane changes, brake lights near hazards
       - density: env.traffic = 'light' | true | 'heavy'  */
    var density = env.traffic === 'heavy' ? 8 : env.traffic === 'light' ? 3 : 5;
    var span = drive ? viewDistance * 1.15 : (zFar - Z_NEAR - 4) / (drive ? mScale : 1);
    var cruiseLanes = Math.max(lanes - (lanes >= 3 ? 1 : 0), 1);
    var trafficInfo = drive ? [] : null;
    for (var vk = 0; vk < density; vk++) {
      var fast = vk % 3 === 2 && lanes >= 2;             // every third vehicle overtakes us
      var rel = fast ? 1.22 + 0.08 * (vk % 2) : 0.42 + 0.11 * (vk % 4);
      var seed = vk * 61.7 + 13;
      var relDist;
      if (drive) {
        relDist = (((seed + (rel - 1) * progress) % span) + span) % span + 5;
      } else {
        relDist = (((seed + (rel - 1) * frame * 0.5) % span) + span) % span + 3;
      }
      var vz = drive ? Z_NEAR + relDist * mScale : Z_NEAR + relDist;
      if (vz < Z_NEAR + 1.2 || vz > zFar - 1) continue;

      /* lane: fast traffic uses the outermost (overtaking) lane; slow traffic
         spreads over cruising lanes with an occasional smooth lane change */
      var baseLane = fast ? lanes - 1 : vk % cruiseLanes;
      var phase = drive ? progress * 0.008 + vk * 2.3 : frame * 0.006 + vk * 2.3;
      var shift = clamp(Math.sin(phase) * 3 - 2, 0, 1);  // mostly 0, smooth ramp to 1
      var laneF = fast ? baseLane : Math.min(baseLane + shift, cruiseLanes - 1);
      var vx = -halfW + (laneF + 0.5) * LANE_W;

      /* brake lights when the vehicle itself is close to a mapped hazard */
      var braking = false;
      if (drive) {
        var vAbs = progress + relDist;
        for (var be = 0; be < evAll.length; be++) {
          var bev = evAll[be];
          var bT = getEventType(bev.type);
          var bl = bev.length != null ? bev.length : bT.len;
          if (vAbs >= bev.at - 28 && vAbs <= bev.at + bl && bT.tone !== 'accent') { braking = true; break; }
        }
      }

      var bus = vk % 3 === 0;
      var vw = bus ? 2.3 : 1.9, vd = bus ? 4.2 : 2.5, vh = bus ? 1.9 : 1.1;
      var fadeV = clamp(1.15 - (vz - Z_NEAR) / zSpan, 0.25, 0.85);
      envBox(vx - vw / 2, vz, vw, vd, vh, fadeV * 0.6);
      // cab / windshield line
      line3(vx - vw / 2, vh, vz + vd, vx + vw / 2, vh, vz + vd, 'glow', fadeV * 0.6);
      if (bus) line3(vx - vw / 2, vh * 0.55, vz, vx - vw / 2, vh * 0.55, vz + vd, 'glow', fadeV * 0.4);
      // brake light bar across the rear (faces the driver)
      if (braking) {
        var flick = 0.7 + 0.3 * Math.sin(frame * 0.5 + vk);
        line3(vx - vw / 2 + 0.15, vh * 0.55, vz, vx + vw / 2 - 0.15, vh * 0.55, vz, 'danger', flick);
      }
      if (trafficInfo) trafficInfo.push({
        distance: Math.round(relDist), lane: Math.round(laneF),
        overtaking: fast, braking: braking, kind: bus ? 'bus' : 'car',
      });
    }
    if (trafficInfo) {
      trafficInfo.sort(function (a, b) { return a.distance - b.distance; });
      var TRAFFIC_OUT = trafficInfo; // attached to driveInfo below
      opts.__traffic = TRAFFIC_OUT;
    }
  }

  /* ---- POIs: petrol pump / rest stop / mechanic at route chainage ---- */
  var pois = opts.pois || (route ? route.pois : null) || [];
  if (drive && pois.length) {
    for (var pi = 0; pi < pois.length; pi++) {
      var poi = pois[pi];
      var pz = mToZ(poi.at);
      if (pz < Z_NEAR + 0.5 || pz > zFar) continue;
      var pSide = poi.side === 'left' ? -1 : 1;
      var pX = pSide * (halfW + 5.5);
      var fadePOI = clamp(1.2 - pz / zFar, 0.25, 0.85);
      drawPOI(line3, poi.type, pX, pz, pSide, fadePOI * 0.7, frame);
    }
  }

  /* ---- LIVE camera detections: dynamic boxes from the onboard AI ----
     opts.detections = [{ id, type, distance (m ahead), lane | lateral (m from
     road center), width?, height? (m), confidence? 0..1, label? }] */
  var dets = opts.detections || [];
  var detInfo = null;
  if (drive && dets.length && (!opts.show || opts.show.detections !== false)) {
    detInfo = [];
    var mLat = LANE_W / ((route && route.laneWidthM) || 3.5); // world units per meter, lateral
    for (var di = 0; di < dets.length; di++) {
      var det = dets[di];
      var DT = DETECTION_TYPES[det.type] || DETECTION_TYPES['obstacle'];
      var dzz = Z_NEAR + det.distance * mScale;
      if (dzz < Z_NEAR + 0.4 || dzz > zFar) continue;
      var xw = det.lane != null
        ? -halfW + (Math.min(det.lane, lanes - 1) + 0.5) * LANE_W
        : det.lateral != null ? det.lateral * mLat : 0;
      var dw = (det.width != null ? det.width : DT.w) * mLat;
      var dh = (det.height != null ? det.height : DT.h) * mLat;
      var dd = Math.max(DT.d * mLat * 0.55, 1.1);
      var conf = det.confidence != null ? det.confidence : 0.8;
      var pulse = 0.7 + 0.3 * Math.sin(frame * 0.22 + di * 2.1);
      var lvl = (0.45 + 0.55 * conf) * pulse;
      wireBox(line3, xw - dw / 2, 0, dzz - dd / 2, dw, dd, dh, DT.tone, lvl);
      line3(xw, dh, dzz, xw, dh + 0.7, dzz, DT.tone, lvl); // marker stem
      var detTxt = (det.label || DT.name) + ' ' + Math.round(det.distance) + 'm' +
        (det.confidence != null ? ' ' + Math.round(conf * 100) + '%' : '');
      if (!opts.show || opts.show.detLabels !== false) {
        overlays0detPush(overlaysDet, {
          kind: 'det-label',
          x: clamp(projX(xw, dzz) / W, 0.03, 0.97),
          y: clamp(projY(dh + 1.0, dzz) / H, 0.02, 0.95),
          on: true, tone: DT.tone, text: detTxt,
        });
      }
      detInfo.push({ id: det.id, type: det.type, name: DT.name, distance: det.distance, confidence: conf });
    }
  }

  /* ---- custom user geometry hook: compose your own 3D objects ---- */
  if (env.custom) {
    env.custom({
      line3: line3,
      box: function (x, y0, z, w, d, hh, tone, lvl) { wireBox(line3, x, y0, z, w, d, hh, tone, lvl); },
      pyramid: function (x, y0, z, w, d, apexH, tone, lvl) { wirePyramid(line3, x, y0, z, w, d, apexH, tone, lvl); },
      ngon: function (cx, cy, z, r, n, tone, lvl) { wireNgon(line3, cx, cy, z, r, n, tone, lvl); },
      sign: function (x, z, poleH, w, bh, tone, lvl) { wireSign(line3, x, z, poleH, w, bh, tone, lvl); },
      flag: function (x, z, poleH, tone, lvl, wave) { wireFlag(line3, x, z, poleH, tone, lvl, wave); },
      mToZ: mToZ, scroll: scroll, progress: progress, frame: frame,
      halfW: halfW, zNear: Z_NEAR, zFar: zFar, drive: drive,
    });
  }

  /* ---- electric poles + wires (every ~30 m in drive mode) ---- */
  if (poles) {
    var GAP = drive ? Math.max(30 * mScale, 4) : 10;
    var PH = 4.6, ARM = 1.7;
    var px = halfW + 3;
    var zwFirst = Math.ceil((scroll + Z_NEAR) / GAP) * GAP;
    for (var side = -1; side <= 1; side += 2) {
      var sx = side * px;
      for (var zw2 = zwFirst; zw2 < scroll + zFar; zw2 += GAP) {
        var z1 = zw2 - scroll;
        var fadeP = clamp(1.2 - z1 / zFar, 0.2, 0.8);
        line3(sx, 0, z1, sx, PH, z1, 'glow', fadeP * 0.55);
        line3(sx - ARM / 2, PH, z1, sx + ARM / 2, PH, z1, 'glow', fadeP * 0.55);
        var z2 = z1 + GAP, zm = z1 + GAP / 2;
        for (var woff = -ARM / 2 + 0.2; woff <= ARM / 2; woff += ARM - 0.4) {
          line3(sx + woff, PH, z1, sx + woff, PH - 0.6, zm, 'glow', fadeP * 0.35);
          line3(sx + woff, PH - 0.6, zm, sx + woff, PH, z2, 'glow', fadeP * 0.35);
        }
      }
    }
  }

  var paths = [];
  for (var key in buckets) paths.push(buckets[key]);
  paths.sort(function (p1, p2) { return (p1.level + p1.fade) - (p2.level + p2.fade); });

  /* ---- overlays ---- */
  var overlays = overlaysDet.slice();
  var driveInfo = null;
  /* opts.show: per-overlay-kind visibility. Default all ON (backwards
     compatible). Set e.g. { score:false, rqi:false, queue:false,
     policy:false } to keep the canvas clean and render that info in your
     own components from onDriveInfo. */
  var show = opts.show || {};
  function sh(k) { return show[k] !== false; }

  if (drive) {
    var next = null;
    for (var n2 = 0; n2 < active.length; n2++) {
      var A5 = active[n2];
      if (A5.ev.at + A5.len < progress) continue;
      if (!next || A5.ev.at < next.ev.at) next = A5;
    }
    if (next) {
      var dist = Math.max(0, Math.round(next.ev.at - progress));
      var passing = next.ev.at <= progress;
      var blinkP = passing ? 10 : dist < 50 ? 16 : dist < 120 ? 26 : 40;
      var on = frame % blinkP < blinkP / 2;
      var name = next.T.name;
      var signText = next.T.sign === 'circle'
        ? String(next.ev.value != null ? next.ev.value : 40)
        : (next.T.signText || '!');
      if (sh('signs') && next.T.sign && next.T.sign !== 'none') {
        overlays.push({ kind: 'sign-' + next.T.sign, x: 0.5, y: 0.095, on: on, text: signText, tone: next.T.tone });
      }
      var bannerY = next.T.sign !== 'none' ? 0.225 : 0.06;
      if (sh('banner')) overlays.push({
        kind: 'banner', x: 0.5, y: bannerY,
        on: on, tone: next.T.tone,
        text: passing ? name + ' NOW' : name + ' IN ' + dist + 'm',
      });
      /* severity-based slow-to (RoadIntel §8.2: impact force ~ speed^2) */
      var slowTo = next.ev.slowTo;
      if (slowTo == null && next.T.tone === 'danger' && next.T.name !== 'SLOW DOWN') {
        slowTo = next.sev >= 0.8 ? 30 : next.sev >= 0.5 ? 40 : 50;
      }
      var sub1 = [];
      if (next.ev.note) sub1.push(next.ev.note);
      if (slowTo != null) sub1.push('slow to ' + slowTo);
      if (sh('sublines') && sub1.length) {
        overlays.push({ kind: 'subline', x: 0.5, y: bannerY + 0.055, on: true, tone: next.T.tone, text: sub1.join(' \u00b7 ') });
      }
      /* confidence + freshness (stale warnings destroy trust) */
      if (sh('sublines') && (next.ev.confidence || next.ev.verifiedAt)) {
        var sub2 = [];
        if (next.ev.confidence) sub2.push('confidence ' + next.ev.confidence);
        if (next.ev.verifiedAt) sub2.push('verified ' + next.ev.verifiedAt);
        overlays.push({ kind: 'subline', x: 0.5, y: bannerY + (sub1.length ? 0.103 : 0.055), on: true, tone: 'neutral', text: sub2.join(' \u00b7 ') });
      }
      driveInfo = {
        nextEvent: next.ev, distance: dist, passing: passing, slowTo: slowTo,
        bestLane: bestLane, effQuality: effQ, advisory: advisory,
      };
    } else {
      if (sh('banner')) overlays.push({ kind: 'banner', x: 0.5, y: 0.06, on: true, tone: 'accent', text: 'ROAD CLEAR' });
      driveInfo = { nextEvent: null, distance: null, passing: false, slowTo: null, bestLane: bestLane, effQuality: effQ, advisory: advisory };
    }
    /* one-sentence lane policy for the window (RoadIntel voice UX) */
    if (advise && advisory) {
      var policy = policySentence(advisory, viewDistance);
      if (sh('policy')) overlays.push({
        kind: 'label', x: 0.5, y: 0.8, on: true,
        tone: advisory.reduceSpeed ? 'danger' : 'accent',
        text: policy,
      });
      if (driveInfo) driveInfo.policyText = policy;
    }
    /* upcoming-events queue (top-right) — full route is preloaded, so the
       next N events are always known */
    var showUp = opts.showUpcoming;
    if (showUp && evAll.length) {
      var drawQueue = sh('queue');
      var upList = [];
      for (var ui = 0; ui < evAll.length && upList.length < showUp; ui++) {
        var uev = evAll[ui];
        var uT = getEventType(uev.type);
        var ulen = uev.length != null ? uev.length : uT.len;
        if (uev.at + ulen < progress) continue;
        upList.push({ ev: uev, T: uT, dist: Math.max(0, Math.round(uev.at - progress)) });
      }
      // sorted by at (route events are pre-sorted; opts.events may not be)
      upList.sort(function (u1, u2) { return u1.ev.at - u2.ev.at; });
      if (drawQueue) for (var uq = 0; uq < upList.length; uq++) {
        overlays.push({
          kind: 'queue', x: 0.975, y: 0.06 + uq * 0.055, on: true,
          tone: uq === 0 ? upList[uq].T.tone : 'neutral',
          text: (upList[uq].dist > 0 ? upList[uq].dist + 'm' : 'NOW') + ' \u00b7 ' + upList[uq].T.name,
        });
      }
      if (driveInfo) driveInfo.upcoming = upList.map(function (u) {
        return { event: u.ev, name: u.T.name, tone: u.T.tone, distance: u.dist, passing: u.ev.at <= progress };
      });
    }

    /* driver trip compliance score (Captain Score) — top-left */
    if (sh('score') && opts.compliance && opts.compliance.score != null) {
      var cs = opts.compliance.score;
      overlays.push({
        kind: 'score', x: 0.035, y: 0.065, on: true,
        tone: cs >= 80 ? 'accent' : cs >= 60 ? 'warn' : 'danger',
        text: (opts.compliance.label || 'TRIP SCORE') + ' ' + cs,
      });
    }

    /* celebration: winning arrow + stars on major event mitigation.
       opts.celebrate = { t: 0..1 animation phase, text } */
    if (opts.celebrate && opts.celebrate.t != null && opts.celebrate.t < 1) {
      overlays.push({
        kind: 'celebrate', x: 0.5, y: 0.48, on: true, tone: 'accent',
        phase: opts.celebrate.t,
        text: opts.celebrate.text || 'WELL HANDLED',
      });
    }

    /* POI labels floating above structures + upcoming amenities info */
    if (pois.length) {
      var amen = [];
      for (var pl = 0; pl < pois.length; pl++) {
        var poi2 = pois[pl];
        var PT = POI_TYPES[poi2.type] || { name: poi2.type.toUpperCase() };
        var pd = poi2.at - progress;
        if (pd >= -20 && pd <= viewDistance) {
          if (sh('poiLabels')) {
            var pz2 = mToZ(poi2.at);
            if (pz2 > Z_NEAR + 1) {
              var pSide2 = poi2.side === 'left' ? -1 : 1;
              overlays.push({
                kind: 'poi-label',
                x: clamp(projX(pSide2 * (halfW + 5.5), pz2) / W, 0.03, 0.97),
                y: clamp((projY(3.6, pz2)) / H, 0.02, 0.95),
                on: true, tone: PT.tone || 'neutral',
                text: PT.name,
              });
            }
          }
        }
        if (pd >= -10 && amen.length < 3) {
          amen.push({ type: poi2.type, name: PT.name, distance: Math.max(0, Math.round(pd)), side: poi2.side || 'right' });
        }
      }
      if (driveInfo) driveInfo.amenities = amen;
    }
    if (driveInfo && opts.__traffic) driveInfo.traffic = opts.__traffic;
    if (driveInfo && detInfo) { driveInfo.detections = detInfo;
    }

    /* driver's own lane (chosen/camera-detected): YOU marker on the road */
    if (opts.driverLane != null && sh('youMarker') && lanes > 0) {
      var dl = Math.max(0, Math.min(lanes - 1, opts.driverLane));
      var dlx = -halfW + (dl + 0.5) * LANE_W;
      var zy = Z_NEAR + 0.12; // right at the driver, bottom of the view
      overlays.push({
        kind: 'you',
        x: clamp(projX(dlx, zy) / W, 0.02, 0.98),
        y: clamp(projY(0, zy) / H, 0, 0.985),
        on: true, tone: 'accent', text: 'YOU',
      });
      if (driveInfo) driveInfo.driverLane = dl;
    }

    /* Trip RQI strip (Figure 8 mockup) */
    if (sh('rqi') && opts.rqi) {
      var rq = opts.rqi;
      var rqiTxt = 'TRIP RQI ' + rq.score + '/100';
      if (rq.compliance != null) rqiTxt += ' \u00b7 COMPLIANCE ' + rq.compliance + '%';
      if (rq.harshEvents != null) rqiTxt += ' \u00b7 ' + rq.harshEvents + ' HARSH';
      overlays.push({
        kind: 'subline', x: 0.5, y: 0.965, on: true,
        tone: rq.score >= 80 ? 'accent' : rq.score >= 60 ? 'warn' : 'danger',
        text: rqiTxt,
      });
    }
  } else if (scene) {
    var base = scene.overlay || { sign: 'none', text: scene.name, blink: 0 };
    var ov = opts.overlay || {};
    var sign = ov.sign != null ? ov.sign : base.sign;
    var text = ov.text != null ? ov.text : base.text;
    var signText2 = ov.signText != null ? ov.signText : base.signText;
    var blinkP2 = ov.blink != null ? ov.blink : base.blink;
    var tone = ov.tone != null ? ov.tone : (base.tone || 'accent');
    var on2 = blinkP2 > 0 ? frame % blinkP2 < blinkP2 / 2 : true;
    var hasSign = sign && sign !== 'none';
    if (hasSign) overlays.push({ kind: 'sign-' + sign, x: 0.5, y: 0.105, on: on2, text: signText2 || '', tone: tone });
    if (text) overlays.push({ kind: 'label', x: 0.5, y: hasSign ? 0.235 : 0.06, on: on2, text: text, tone: tone });
  }

  /* per-lane score + role labels (Figure 5: "45 \u2014 AVOID") */
  var laneInfo = null;
  if (laneQuality) {
    laneInfo = [];
    var ROLE_SHORT = { PRIMARY: 'BEST', FALLBACK: 'FALLBACK', AVOID: 'AVOID', EXCLUDED: 'OVERTAKE', OK: '' };
    for (var li5 = 0; li5 < lanes; li5++) {
      var qv2 = effQ ? Math.round(effQ[li5]) : laneQuality[li5];
      if (qv2 == null) continue;
      var role = advisory ? advisory.roles[li5] : (li5 === bestLane ? 'PRIMARY' : 'OK');
      var tone2 = role === 'EXCLUDED' ? 'neutral'
        : role === 'PRIMARY' ? 'accent'
        : role === 'AVOID' ? 'danger'
        : laneClass(qv2) === 'glow' ? 'accent' : laneClass(qv2);
      laneInfo.push({ lane: li5, score: qv2, role: role, roleShort: ROLE_SHORT[role] || '', tone: tone2 });
      var laneCx = -halfW + li5 * LANE_W + LANE_W / 2;
      if (show['laneLabels'] !== false) {
        var lx = projX(laneCx, Z_NEAR + 2.6) / W;
        overlays.push({
          kind: 'lane-label',
          x: clamp(lx, 0.04, 0.96), y: 0.9, on: true,
          text: 'L' + (li5 + 1) + ' \u00b7 ' + qv2 + '%',
          roleText: ROLE_SHORT[role] || '',
          tone: tone2,
          best: role === 'PRIMARY',
        });
      }
      if (show['laneNumbers'] !== false) {
        // lane number painted on the road surface (projected onto the ground)
        var zn = Z_NEAR + 1.7; // nearer = larger, clearer
        overlays.push({
          kind: 'lane-num',
          x: clamp(projX(laneCx, zn) / W, 0.02, 0.98),
          y: clamp(projY(0, zn) / H, 0, 0.98),
          on: true,
          text: 'L' + (li5 + 1),
          tone: role === 'PRIMARY' ? 'accent' : role === 'AVOID' ? 'danger' : 'neutral',
        });
      }
    }
    if (driveInfo) driveInfo.laneInfo = laneInfo;
  }

  return { paths: paths, overlays: overlays, scene: scene, drive: driveInfo, laneInfo: laneInfo };
}
