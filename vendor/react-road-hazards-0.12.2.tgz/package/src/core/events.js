/* Event types for DRIVE MODE (v0.3).
 * Each event on the route: { id, type, at (meters), lane (index, optional),
 *   length (m, optional), severity 0..1 (optional), value (e.g. speed limit) }
 *
 * Each type defines:
 *   name, sign, signText, tone   - overlay defaults ("POTHOLE IN 120m")
 *   len                          - default event length in meters
 *   lanePenalty                  - how much this event degrades its lane's
 *                                  effective quality for lane guidance
 *   field(dx, dz, lw, sev, zw, f)- localized mesh effect. dx = world-x offset
 *       from event center, dz = world-z offset from event center, lw = event
 *       length in world units, sev = severity, zw = absolute world z.
 *       Returns { h, g, d, w } (height, green, red, amber), any subset.
 *   skip(dx, dz, lw)             - optional missing-segment test
 *   geometry(line3, xe, ze, sev, f) - optional 3D wireframe at event site
 *   roadShift(m, ev)             - optional lateral road shift in meters-space
 */
import { rnd, smoothNoise, gauss, clamp } from './scenes.js';

var band = function (dz, lw) { return Math.abs(dz) < lw / 2 ? 1 : 0; };

export var EVENT_TYPES = {
  'pothole': {
    name: 'POTHOLE', sign: 'triangle', signText: '!', tone: 'danger',
    len: 6, lanePenalty: 45,
    field: function (dx, dz, lw, sev) {
      var r = 0.9 + sev * 1.7;
      var rad = Math.hypot(dx / r, dz / r);
      return { h: -2.6 * (0.4 + sev) * gauss(rad, 0.55), d: gauss(rad - 1, 0.3) };
    },
  },
  'speed-breaker': {
    name: 'SPEED BREAKER', sign: 'triangle', signText: '!', tone: 'danger',
    len: 4, lanePenalty: 10, fullWidth: true,
    field: function (dx, dz, lw, sev) {
      return { h: 1.7 * gauss(dz, 0.8), d: gauss(dz, 1.0) };
    },
  },
  'multiple-speed-breakers': {
    name: 'SPEED BREAKERS', sign: 'triangle', signText: '!', tone: 'danger',
    len: 30, lanePenalty: 10, fullWidth: true,
    field: function (dx, dz, lw, sev) {
      var h = 0, d = 0, n = 3, sp = lw / n;
      for (var k = 0; k < n; k++) {
        var c = -lw / 2 + sp * (k + 0.5);
        h += 1.6 * gauss(dz - c, 0.7);
        d += gauss(dz - c, 0.9);
      }
      return { h: h, d: clamp(d, 0, 1) };
    },
  },
  'broken-road': {
    name: 'BROKEN ROAD', sign: 'x', tone: 'danger',
    len: 40, lanePenalty: 40,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      return {
        h: 0.5 * (rnd(Math.round(dx) + 7, Math.round(zw)) - 0.5),
        d: rnd(Math.round(dx), Math.round(zw) + 5) > 0.8 ? 0.9 : 0.15,
      };
    },
    skip: function (dx, dz, lw, zw) {
      return band(dz, lw) && rnd(Math.round(dx), Math.floor(zw)) > 0.74;
    },
  },
  'rough-road': {
    name: 'ROUGH ROAD', sign: 'triangle', signText: '!', tone: 'warn',
    len: 50, lanePenalty: 25,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      return {
        h: 0.4 * (rnd(Math.round(dx), Math.round(zw)) - 0.5),
        w: rnd(Math.round(dx) + 3, Math.round(zw)) > 0.65 ? 0.6 : 0.1,
      };
    },
  },
  'bumpy-ride': {
    name: 'BUMPY ROAD', sign: 'triangle', signText: '!', tone: 'warn',
    len: 45, lanePenalty: 20,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      var n = smoothNoise(dx * 1.3, zw * 1.3);
      return { h: 0.8 * n, w: clamp(n - 0.35, 0, 1) * 1.4 };
    },
  },
  'crack-road': {
    name: 'CRACKED SURFACE', sign: 'none', tone: 'warn',
    len: 35, lanePenalty: 15,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      var c = gauss(dx - 1.4 * Math.sin(zw * 0.8), 0.5);
      return { h: -0.5 * c, w: c };
    },
  },
  'undulation': {
    name: 'UNDULATION', sign: 'none', tone: 'warn',
    len: 60, lanePenalty: 12, fullWidth: true,
    field: function (dx, dz, lw) {
      if (!band(dz, lw)) return null;
      var s = Math.sin(dz * 1.6);
      return { h: 1.2 * s, w: clamp(s, 0, 1) * 0.6 };
    },
  },
  'road-crossing': {
    name: 'PEDESTRIAN CROSSING', sign: 'none', tone: 'accent',
    len: 5, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      return { g: Math.floor(zw) % 2 === 0 ? 0.95 : 0 };
    },
  },
  'school-area': {
    name: 'SCHOOL AREA', sign: 'triangle', signText: '!', tone: 'danger',
    len: 100, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw, sev, zw) {
      if (!band(dz, lw)) return null;
      // zebra at each end of the zone
      var e = Math.min(Math.abs(dz + lw / 2), Math.abs(dz - lw / 2));
      if (e < 1.2) return { g: Math.floor(zw) % 2 === 0 ? 0.95 : 0 };
      return null;
    },
  },
  'slow-down': {
    name: 'SLOW DOWN', sign: 'triangle', signText: '!', tone: 'danger',
    len: 20, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw, sev, zw, f) {
      return { d: (f % 26 < 13 ? 0.9 : 0.25) * gauss(dz, lw / 4) };
    },
  },
  'speed-limit': {
    name: 'SPEED LIMIT', sign: 'circle', tone: 'danger',
    len: 20, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw, sev, zw, f) {
      return { g: (f % 40 < 20 ? 0.5 : 0.2) * gauss(dz, lw / 4) };
    },
  },
  'intersection': {
    name: 'INTERSECTION', sign: 'none', tone: 'accent',
    len: 12, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw) {
      return { g: Math.abs(dz) < lw / 2 ? 0.9 : 0 };
    },
  },
  'checkpost': {
    name: 'CHECK POST', sign: 'none', tone: 'accent',
    len: 8, lanePenalty: 0, fullWidth: true,
    field: function (dx, dz, lw, sev, zw, f) {
      return { g: gauss(dz, 0.8) * 0.4 };
    },
    geometry: function (line3, halfW, ze, sev, f) {
      var on = f % 16 < 8 ? 1 : 0.35;
      line3(-halfW, 0, ze, -halfW, 3, ze, 'glow', 1);
      line3(halfW, 0, ze, halfW, 3, ze, 'glow', 1);
      var n = Math.round(halfW * 2);
      for (var s = 0; s < n; s++) {
        var xa = -halfW + s, xb = -halfW + s + 1;
        if (s % 2 === 0) line3(xa, 3, ze, xb, 3, ze, 'danger', on);
        else line3(xa, 3, ze, xb, 3, ze, 'glow', 0.6);
      }
    },
  },
  'accident': {
    name: 'ACCIDENT', sign: 'x', tone: 'danger',
    len: 10, lanePenalty: 70,
    field: function () { return null; },
    geometry: function (line3, xe, ze, sev, f) {
      boxWire(line3, xe - 1.8, ze, 2.2, 1.4, 0.8);
      boxWire(line3, xe + 0.2, ze - 1.2, 2.2, 1.4, 0.8);
    },
    laneGeometry: true, // geometry positioned at the event lane, not road edge
  },
  'diversion': {
    name: 'DIVERSION', sign: 'arrow', tone: 'accent',
    len: 80, lanePenalty: 0, fullWidth: true,
    roadShift: function (m, ev) {
      var t = clamp((m - ev.at) / (ev.length || 80), 0, 1);
      // ramp out and back
      return 4.5 * Math.sin(t * Math.PI) * (ev.severity != null ? ev.severity : 1);
    },
  },
  'curve-road': {
    name: 'CURVE AHEAD', sign: 'arrow', tone: 'accent',
    len: 100, lanePenalty: 0, fullWidth: true,
    roadShift: function (m, ev) {
      var t = clamp((m - ev.at) / (ev.length || 100), 0, 1);
      return 3.5 * Math.sin(t * Math.PI * 2);
    },
  },
};

function boxWire(line3, x, z, w, d, h) {
  var c = [
    [x, 0, z], [x + w, 0, z], [x + w, 0, z + d], [x, 0, z + d],
    [x, h, z], [x + w, h, z], [x + w, h, z + d], [x, h, z + d],
  ];
  var e = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
  ];
  for (var i = 0; i < e.length; i++) {
    var a = c[e[i][0]], b = c[e[i][1]];
    line3(a[0], a[1], a[2], b[0], b[1], b[2], 'danger', 0.9);
  }
}

export function getEventType(type) {
  return EVENT_TYPES[type] || EVENT_TYPES['pothole'];
}
