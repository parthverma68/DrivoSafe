/* Geolocation (v0.9) — real GPS to route chainage.
 *
 * The corridor centerline comes from your mapper as a GPS polyline. This
 * module linear-references it (the same route chainage + lane + offset model
 * as your PostGIS store) and map-matches live fixes onto it:
 *
 *   const route = createRoute({
 *     path: [{ lat, lng }, ...],   // corridor centerline, in driving order
 *     laneWidthM: 3.5,             // real lane width (default 3.5 m)
 *     lanes: 4,
 *     events: [...], pois: [...],
 *   });
 *
 *   route.matchProgress(lat, lng)
 *     -> { progress,   // chainage meters along the corridor
 *          offset,     // signed lateral meters (+ = right of centerline)
 *          distance,   // absolute meters from centerline
 *          laneGuess,  // estimated lane index from the offset
 *          onRoute }   // distance within tolerance
 *
 *   const gps = createGpsTracker(route);
 *   navigator.geolocation.watchPosition((p) => {
 *     const s = gps.push({
 *       lat: p.coords.latitude, lng: p.coords.longitude,
 *       accuracy: p.coords.accuracy, speed: p.coords.speed,
 *       timestamp: p.timestamp,
 *     });
 *     setProgress(s.progress);           // feed the HUD
 *     tracker.update({ progress: s.progress, speed: s.speedKmh, ... });
 *   });
 *
 * The tracker smooths noise, rejects outliers, dead-reckons between fixes
 * using speed, and flags off-route. React Native: feed fixes from
 * expo-location / @react-native-community/geolocation the same way.
 */

var R_EARTH = 6371000;
var D2R = Math.PI / 180;

export function haversineM(lat1, lng1, lat2, lng2) {
  var dLat = (lat2 - lat1) * D2R;
  var dLng = (lng2 - lng1) * D2R;
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * D2R) * Math.cos(lat2 * D2R) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return 2 * R_EARTH * Math.asin(Math.sqrt(a));
}

/* precompute a linear-referenced path: local-meter coordinates + cumulative
   chainage. Equirectangular projection around the path start is accurate to
   well under a meter for corridor-scale extents. */
export function buildPath(points) {
  if (!points || points.length < 2) return null;
  var lat0 = points[0].lat * D2R;
  var kx = Math.cos(lat0) * R_EARTH * D2R; // meters per degree lng
  var ky = R_EARTH * D2R;                  // meters per degree lat
  var xs = [], ys = [], cum = [0];
  for (var i = 0; i < points.length; i++) {
    xs.push((points[i].lng - points[0].lng) * kx);
    ys.push((points[i].lat - points[0].lat) * ky);
    if (i > 0) {
      var dx = xs[i] - xs[i - 1], dy = ys[i] - ys[i - 1];
      cum.push(cum[i - 1] + Math.sqrt(dx * dx + dy * dy));
    }
  }
  return {
    points: points, xs: xs, ys: ys, cum: cum,
    length: cum[cum.length - 1],
    lng0: points[0].lng, lat0deg: points[0].lat, kx: kx, ky: ky,
  };
}

/* project a fix onto the path. hint = last segment index (search window). */
export function matchToPath(path, lat, lng, hint) {
  var px = (lng - path.lng0) * path.kx;
  var py = (lat - path.lat0deg) * path.ky;
  var n = path.xs.length;
  var i0 = 0, i1 = n - 2;
  if (hint != null) {
    i0 = Math.max(0, hint - 40);
    i1 = Math.min(n - 2, hint + 40);
  }
  var best = null;
  for (var pass = 0; pass < 2; pass++) {
    for (var i = i0; i <= i1; i++) {
      var ax = path.xs[i], ay = path.ys[i];
      var bx = path.xs[i + 1], by = path.ys[i + 1];
      var dx = bx - ax, dy = by - ay;
      var len2 = dx * dx + dy * dy;
      var t = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
      t = Math.max(0, Math.min(1, t));
      var qx = ax + t * dx, qy = ay + t * dy;
      var ddx = px - qx, ddy = py - qy;
      var d2 = ddx * ddx + ddy * ddy;
      if (!best || d2 < best.d2) {
        // signed offset: + = right of travel direction (cross product sign)
        var cross = dx * (py - ay) - dy * (px - ax);
        best = {
          d2: d2, seg: i, t: t,
          progress: path.cum[i] + t * Math.sqrt(len2),
          offset: (cross >= 0 ? -1 : 1) * Math.sqrt(d2),
        };
      }
    }
    // windowed search found nothing convincing? widen to full path once
    if (pass === 1 || hint == null || (best && Math.sqrt(best.d2) < 60)) break;
    i0 = 0; i1 = n - 2; best = null;
  }
  return best;
}

/* map lateral offset (m from centerline) to a lane index */
export function laneFromOffset(offset, lanes, laneWidthM) {
  var w = laneWidthM || 3.5;
  var half = (lanes * w) / 2;
  var idx = Math.floor((offset + half) / w);
  return Math.max(0, Math.min(lanes - 1, idx));
}

/* smoothing GPS tracker: outlier rejection, dead reckoning, off-route flag */
export function createGpsTracker(route, cfg) {
  cfg = cfg || {};
  var offRouteM = cfg.offRouteMeters != null ? cfg.offRouteMeters : 30;
  var maxJumpM = cfg.maxJumpMeters != null ? cfg.maxJumpMeters : 80;
  var alpha = cfg.smoothing != null ? cfg.smoothing : 0.5;
  var maxAcc = cfg.maxAccuracyMeters != null ? cfg.maxAccuracyMeters : 40;
  var lanesN = cfg.lanes != null ? cfg.lanes : route.lanes;
  var laneW = cfg.laneWidthM != null ? cfg.laneWidthM : route.laneWidthM;

  var st = {
    progress: 0, offset: 0, laneGuess: null, onRoute: false,
    speedKmh: 0, lastTs: null, lastFixProgress: null, seg: null,
    pendingJump: null, initialized: false,
  };

  function push(fix) {
    var path = route.path;
    if (!path) return st;
    var ts = fix.timestamp != null ? fix.timestamp : Date.now();
    var dt = st.lastTs != null ? Math.max(0, (ts - st.lastTs) / 1000) : 0;

    // dead-reckon forward with last known speed regardless of fix quality
    var predicted = st.progress + (st.speedKmh / 3.6) * dt;

    var usable = fix.accuracy == null || fix.accuracy <= maxAcc;
    var m = usable ? matchToPath(path, fix.lat, fix.lng, st.seg) : null;

    if (m) {
      var dist = Math.abs(m.offset);
      var onRoute = dist <= offRouteM;
      if (onRoute) {
        var jump = Math.abs(m.progress - (st.initialized ? predicted : m.progress));
        if (!st.initialized) {
          st.progress = m.progress;
          st.initialized = true;
          st.pendingJump = null;
        } else if (jump <= maxJumpM) {
          st.progress = predicted + alpha * (m.progress - predicted);
          st.pendingJump = null;
        } else if (st.pendingJump != null && Math.abs(m.progress - st.pendingJump) < maxJumpM) {
          st.progress = m.progress; // two consistent far fixes = real relocation
          st.pendingJump = null;
        } else {
          st.pendingJump = m.progress; // single outlier: hold, remember
          st.progress = predicted;
        }
        st.offset = m.offset;
        st.laneGuess = laneFromOffset(m.offset, lanesN, laneW);
        st.seg = m.seg;
        st.onRoute = true;
      } else {
        st.onRoute = false;
        st.progress = predicted;
      }
    } else {
      st.progress = predicted; // no usable fix: coast on speed
    }

    if (fix.speed != null && isFinite(fix.speed)) {
      st.speedKmh = Math.max(0, fix.speed * 3.6);
    } else if (st.lastFixProgress != null && dt > 0.2 && m) {
      st.speedKmh = Math.max(0, ((st.progress - st.lastFixProgress) / dt) * 3.6);
    }
    st.lastFixProgress = st.progress;
    st.lastTs = ts;
    return {
      progress: st.progress, offset: st.offset, laneGuess: st.laneGuess,
      onRoute: st.onRoute, speedKmh: Math.round(st.speedKmh),
    };
  }

  return { push: push, state: function () { return st; } };
}
