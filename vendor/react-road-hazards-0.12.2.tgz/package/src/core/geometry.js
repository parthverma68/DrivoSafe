/* Wireframe geometry toolkit (v0.8).
 *
 * Every 3D object in this engine is composed from line segments via
 * line3(x1, h1, z1, x2, h2, z2, tone, level). These primitives let you
 * combine boxes, pyramids, n-gons and polylines into any structure —
 * the built-in POIs (petrol pump, rest stop, mechanic shop) are just
 * compositions of them, and environment.custom lets you add your own.
 */

/* axis-aligned box: base corner (x, y0, z), size w (x) × d (z) × h (up) */
export function wireBox(line3, x, y0, z, w, d, h, tone, lvl) {
  line3(x, y0, z, x + w, y0, z, tone, lvl);
  line3(x + w, y0, z, x + w, y0, z + d, tone, lvl);
  line3(x + w, y0, z + d, x, y0, z + d, tone, lvl);
  line3(x, y0, z + d, x, y0, z, tone, lvl);
  line3(x, y0 + h, z, x + w, y0 + h, z, tone, lvl);
  line3(x + w, y0 + h, z, x + w, y0 + h, z + d, tone, lvl);
  line3(x + w, y0 + h, z + d, x, y0 + h, z + d, tone, lvl);
  line3(x, y0 + h, z + d, x, y0 + h, z, tone, lvl);
  line3(x, y0, z, x, y0 + h, z, tone, lvl);
  line3(x + w, y0, z, x + w, y0 + h, z, tone, lvl);
  line3(x + w, y0, z + d, x + w, y0 + h, z + d, tone, lvl);
  line3(x, y0, z + d, x, y0 + h, z + d, tone, lvl);
}

/* pyramid roof over rectangle (x..x+w, z..z+d) from height y0 to apex */
export function wirePyramid(line3, x, y0, z, w, d, apexH, tone, lvl) {
  var ax = x + w / 2, az = z + d / 2;
  line3(x, y0, z, ax, y0 + apexH, az, tone, lvl);
  line3(x + w, y0, z, ax, y0 + apexH, az, tone, lvl);
  line3(x, y0, z + d, ax, y0 + apexH, az, tone, lvl);
  line3(x + w, y0, z + d, ax, y0 + apexH, az, tone, lvl);
}

/* vertical n-gon ring (like a wheel/tire) facing the driver, in the x-h
   plane at constant z. cx = center x, cy = center height, r = radius */
export function wireNgon(line3, cx, cy, z, r, n, tone, lvl) {
  n = n || 8;
  var px = null, py = null, fx = null, fy = null;
  for (var i = 0; i <= n; i++) {
    var a = (i / n) * Math.PI * 2;
    var vx = cx + Math.cos(a) * r, vy = cy + Math.sin(a) * r;
    if (px != null) line3(px, py, z, vx, vy, z, tone, lvl);
    else { fx = vx; fy = vy; }
    px = vx; py = vy;
  }
}

/* signboard on a pole: pole at (x, z) up to poleH, board w × bh on top */
export function wireSign(line3, x, z, poleH, w, bh, tone, lvl) {
  line3(x, 0, z, x, poleH, z, tone, lvl);
  line3(x - w / 2, poleH, z, x + w / 2, poleH, z, tone, lvl);
  line3(x - w / 2, poleH + bh, z, x + w / 2, poleH + bh, z, tone, lvl);
  line3(x - w / 2, poleH, z, x - w / 2, poleH + bh, z, tone, lvl);
  line3(x + w / 2, poleH, z, x + w / 2, poleH + bh, z, tone, lvl);
}

/* tall waving flag: pole + triangular pennant. wave animates the tip. */
export function wireFlag(line3, x, z, poleH, tone, lvl, wave) {
  line3(x, 0, z, x, poleH, z, 'glow', lvl);
  var tip = 1.6 + (wave || 0);
  var fl = Math.min(1, lvl * 1.8);
  line3(x, poleH, z, x + tip, poleH - 0.4, z, tone, fl);
  line3(x + tip, poleH - 0.4, z, x, poleH - 0.85, z, tone, fl);
  line3(x, poleH - 0.85, z, x, poleH, z, tone, fl);
  line3(x, poleH - 0.42, z, x + tip * 0.55, poleH - 0.42, z, tone, fl * 0.7);
}

/* ---------- POI composites (all built from the primitives above) ---------- */

export var POI_TYPES = {
  'petrol-pump': { name: 'PETROL', span: 8, tone: 'warn', flagH: 6.8 },    // yellow flag
  'rest-stop': { name: 'REST STOP', span: 10, tone: 'accent', flagH: 6.8 }, // green flag
  'mechanic': { name: 'MECHANIC', span: 7, tone: 'danger', flagH: 6.2 },    // red flag
};

/* side: -1 = left of road, +1 = right. x0 = structure center x, ze = center z */
export function drawPetrolPump(line3, x0, ze, side, lvl) {
  // canopy slab on 4 columns
  wireBox(line3, x0 - 2.6, 2.6, ze - 2.4, 5.2, 4.8, 0.3, 'glow', lvl);
  line3(x0 - 2.2, 0, ze - 2.0, x0 - 2.2, 2.6, ze - 2.0, 'glow', lvl);
  line3(x0 + 2.2, 0, ze - 2.0, x0 + 2.2, 2.6, ze - 2.0, 'glow', lvl);
  line3(x0 - 2.2, 0, ze + 2.0, x0 - 2.2, 2.6, ze + 2.0, 'glow', lvl);
  line3(x0 + 2.2, 0, ze + 2.0, x0 + 2.2, 2.6, ze + 2.0, 'glow', lvl);
  // two pump units
  wireBox(line3, x0 - 1.3, 0, ze - 0.4, 0.7, 0.7, 1.15, 'glow', lvl);
  wireBox(line3, x0 + 0.6, 0, ze - 0.4, 0.7, 0.7, 1.15, 'glow', lvl);
  // price sign toward the road
  wireSign(line3, x0 - side * 3.6, ze - 3.4, 3.1, 1.5, 0.9, 'warn', lvl);
}

export function drawRestStop(line3, x0, ze, side, lvl) {
  // main building + door
  wireBox(line3, x0 - 2.2, 0, ze - 1.4, 4.4, 3.0, 2.1, 'glow', lvl);
  line3(x0 - side * 2.2, 0, ze - 0.2, x0 - side * 2.2, 1.4, ze - 0.2, 'glow', lvl);
  line3(x0 - side * 2.2, 1.4, ze - 0.2, x0 - side * 2.2, 1.4, ze + 0.5, 'glow', lvl);
  line3(x0 - side * 2.2, 0, ze + 0.5, x0 - side * 2.2, 1.4, ze + 0.5, 'glow', lvl);
  // bathroom annex (small attached block)
  wireBox(line3, x0 + (side > 0 ? 2.2 : -3.6), 0, ze - 1.0, 1.4, 2.0, 1.5, 'glow', lvl * 0.9);
  // food stall: two poles + slanted canopy + counter
  var fx = x0 - side * 4.2;
  line3(fx - 0.9, 0, ze + 2.2, fx - 0.9, 1.9, ze + 2.2, 'glow', lvl);
  line3(fx + 0.9, 0, ze + 2.2, fx + 0.9, 1.9, ze + 2.2, 'glow', lvl);
  line3(fx - 0.9, 1.9, ze + 2.2, fx - 0.9 - side * 0.8, 2.3, ze + 2.2, 'glow', lvl);
  line3(fx + 0.9, 1.9, ze + 2.2, fx + 0.9 - side * 0.8, 2.3, ze + 2.2, 'glow', lvl);
  line3(fx - 0.9 - side * 0.8, 2.3, ze + 2.2, fx + 0.9 - side * 0.8, 2.3, ze + 2.2, 'glow', lvl);
  wireBox(line3, fx - 0.9, 0, ze + 1.9, 1.8, 0.5, 0.9, 'glow', lvl * 0.85);
  // amenity sign
  wireSign(line3, x0 - side * 3.2, ze - 2.8, 2.8, 1.6, 0.8, 'accent' === 'accent' ? 'glow' : 'glow', lvl);
}

export function drawMechanic(line3, x0, ze, side, lvl) {
  // garage box with open front (frame drawn toward the road)
  wireBox(line3, x0 - 1.9, 0, ze - 1.5, 3.8, 3.0, 2.2, 'glow', lvl);
  var fxx = x0 - side * 1.9;
  line3(fxx, 0.1, ze - 1.1, fxx, 1.9, ze - 1.1, 'glow', lvl); // opening frame
  line3(fxx, 1.9, ze - 1.1, fxx, 1.9, ze + 1.1, 'glow', lvl);
  line3(fxx, 0.1, ze + 1.1, fxx, 1.9, ze + 1.1, 'glow', lvl);
  // slanted roof ridge
  line3(x0 - 1.9, 2.2, ze, x0 + 1.9, 2.2, ze, 'glow', lvl * 0.8);
  line3(x0 - 1.9, 2.2, ze - 1.5, x0, 2.9, ze - 1.5, 'glow', lvl);
  line3(x0 + 1.9, 2.2, ze - 1.5, x0, 2.9, ze - 1.5, 'glow', lvl);
  line3(x0 - 1.9, 2.2, ze + 1.5, x0, 2.9, ze + 1.5, 'glow', lvl);
  line3(x0 + 1.9, 2.2, ze + 1.5, x0, 2.9, ze + 1.5, 'glow', lvl);
  line3(x0, 2.9, ze - 1.5, x0, 2.9, ze + 1.5, 'glow', lvl);
  // spare tires leaning beside the shop (wheel = vertical octagon)
  wireNgon(line3, x0 - side * 3.0, 0.6, ze + 0.6, 0.6, 8, 'glow', lvl);
  wireNgon(line3, x0 - side * 3.0, 0.6, ze + 0.6, 0.28, 8, 'glow', lvl * 0.7);
  wireNgon(line3, x0 - side * 3.4, 0.5, ze + 1.4, 0.5, 8, 'glow', lvl * 0.85);
}

export function drawPOI(line3, type, x0, ze, side, lvl, frame) {
  if (type === 'petrol-pump') drawPetrolPump(line3, x0, ze, side, lvl);
  else if (type === 'rest-stop') drawRestStop(line3, x0, ze, side, lvl);
  else if (type === 'mechanic') drawMechanic(line3, x0, ze, side, lvl);
  var T = POI_TYPES[type];
  if (T) {
    // high colored flag, visible far before the structure resolves
    var wave = 0.3 * Math.sin((frame || 0) * 0.14 + ze * 0.7);
    var flagTone = T.tone === 'accent' ? 'glow' : T.tone;
    wireFlag(line3, x0 + side * 1.2, ze - 3.2, T.flagH, flagTone, Math.min(1, lvl * 1.3), wave);
  }
}
