/* Route-Event Mapping Mechanism (v0.12).
 *
 * The pipeline between the hero/mapper system and the HUD:
 *
 *   LiDAR + GPS + IMU + camera scans
 *        │  (each detected defect = a GeoJSON Point with properties)
 *        ▼
 *   detectionsFromGeoJSON()  +  routeFromGeoJSON()  (corridor LineString)
 *        ▼
 *   mapDetectionsToRoute()   — map-match every point to route chainage +
 *                              lane (from lateral offset); reject off-route
 *        ▼
 *   fuseDetections()         — multi-pass fusion: cluster repeat
 *                              observations of the same physical defect,
 *                              confidence from observation count, severity
 *                              aggregation, extended defects get a length
 *        ▼
 *   km-mapped events[]       — feed straight into createRoute() / the HUD.
 *
 * One-call wrapper: buildRouteEvents(routeGeoJSON, detectionsGeoJSON, opts).
 *
 * Detection GeoJSON feature properties understood:
 *   type       - event type id ('pothole', 'speed-breaker', ...); default 'pothole'
 *   severity   - 0..1, OR depth_mm (LiDAR): severity = clamp(depth_mm / 120)
 *   timestamp  - ISO string or epoch ms (drives freshness / verifiedAt)
 *   lane       - lane index if the mapper already knows it (else derived
 *                from lateral offset)
 *   note       - free text carried onto the event
 */
import { buildPath, matchToPath, laneFromOffset } from './geo.js';
import { getEventType } from './events.js';

var clamp01 = function (v) { return Math.max(0, Math.min(1, v)); };

export function routeFromGeoJSON(gj) {
  var g = gj && gj.type === 'FeatureCollection'
    ? (gj.features.find(function (f) { return f.geometry && f.geometry.type === 'LineString'; }) || {}).geometry
    : gj && gj.type === 'Feature' ? gj.geometry
    : gj;
  if (!g || g.type !== 'LineString') return null;
  return g.coordinates.map(function (c) { return { lat: c[1], lng: c[0] }; });
}

export function detectionsFromGeoJSON(gj) {
  var feats = gj && gj.type === 'FeatureCollection' ? gj.features
    : gj && gj.type === 'Feature' ? [gj] : Array.isArray(gj) ? gj : [];
  var out = [];
  for (var i = 0; i < feats.length; i++) {
    var f = feats[i];
    if (!f.geometry || f.geometry.type !== 'Point') continue;
    var p = f.properties || {};
    var sev = p.severity != null ? clamp01(p.severity)
      : p.depth_mm != null ? clamp01(p.depth_mm / 120)
      : 0.6;
    out.push({
      id: f.id != null ? String(f.id) : p.id != null ? String(p.id) : 'det-' + i,
      lat: f.geometry.coordinates[1],
      lng: f.geometry.coordinates[0],
      type: p.type || 'pothole',
      severity: sev,
      lane: p.lane != null ? p.lane : null,
      timestamp: p.timestamp != null
        ? (typeof p.timestamp === 'number' ? p.timestamp : Date.parse(p.timestamp))
        : null,
      note: p.note || null,
    });
  }
  return out;
}

/* map every detection onto the route; returns { mapped, rejected } */
export function mapDetectionsToRoute(path, detections, opts) {
  opts = opts || {};
  var lanes = opts.lanes || 2;
  var laneWidthM = opts.laneWidthM || 3.5;
  var maxOff = opts.maxOffRouteMeters != null ? opts.maxOffRouteMeters : 30;
  var mapped = [], rejected = [];
  for (var i = 0; i < detections.length; i++) {
    var d = detections[i];
    var m = matchToPath(path, d.lat, d.lng, null);
    if (!m) { rejected.push({ det: d, reason: 'no-match' }); continue; }
    var dist = Math.abs(m.offset);
    if (dist > maxOff) { rejected.push({ det: d, reason: 'off-route', distance: dist }); continue; }
    mapped.push({
      det: d,
      at: m.progress,
      offset: m.offset,
      distance: dist,
      lane: d.lane != null ? d.lane : laneFromOffset(m.offset, lanes, laneWidthM),
    });
  }
  return { mapped: mapped, rejected: rejected };
}

/* multi-pass fusion: repeat observations of one physical defect become one
   event with observation-count confidence */
export function fuseDetections(mapped, opts) {
  opts = opts || {};
  var clusterM = opts.clusterMeters != null ? opts.clusterMeters : 10;
  var sorted = mapped.slice().sort(function (a, b) { return a.at - b.at; });
  var clusters = [];
  for (var i = 0; i < sorted.length; i++) {
    var m = sorted[i];
    var placed = null;
    for (var c = clusters.length - 1; c >= 0; c--) {
      var cl = clusters[c];
      if (cl.type !== m.det.type) continue;
      if (m.at - cl.maxAt > clusterM) break; // sorted: earlier clusters even farther
      var laneOk = cl.lane == null || m.lane == null || cl.lane === m.lane ||
        getEventType(cl.type).fullWidth;
      if (laneOk) { placed = cl; break; }
    }
    if (!placed) {
      placed = { type: m.det.type, obs: [], minAt: m.at, maxAt: m.at, lane: m.lane };
      clusters.push(placed);
    }
    placed.obs.push(m);
    placed.minAt = Math.min(placed.minAt, m.at);
    placed.maxAt = Math.max(placed.maxAt, m.at);
    if (placed.lane == null) placed.lane = m.lane;
  }

  var events = [];
  for (var k = 0; k < clusters.length; k++) {
    var cl2 = clusters[k];
    var n = cl2.obs.length;
    var atSum = 0, sevMax = 0, tsMax = null, note = null;
    var laneCounts = {};
    for (var o = 0; o < n; o++) {
      var ob = cl2.obs[o];
      atSum += ob.at;
      sevMax = Math.max(sevMax, ob.det.severity);
      if (ob.det.timestamp != null && (tsMax == null || ob.det.timestamp > tsMax)) tsMax = ob.det.timestamp;
      if (ob.det.note) note = ob.det.note;
      if (ob.lane != null) laneCounts[ob.lane] = (laneCounts[ob.lane] || 0) + 1;
    }
    var lane = null, ln = -1;
    for (var lk in laneCounts) if (laneCounts[lk] > ln) { ln = laneCounts[lk]; lane = Number(lk); }
    var span = cl2.maxAt - cl2.minAt;
    var T = getEventType(cl2.type);
    var ev = {
      id: cl2.type + '-' + Math.round(cl2.minAt),
      type: cl2.type,
      at: Math.round(span > 12 ? cl2.minAt : atSum / n),
      severity: Math.round(sevMax * 100) / 100,
      confidence: n >= 3 ? 'high' : n === 2 ? 'med' : 'low',
      observations: n,
    };
    if (span > 12) ev.length = Math.round(span + 6);
    if (lane != null && !T.fullWidth) ev.lane = lane;
    if (note) ev.note = note;
    if (tsMax != null) {
      var dt = new Date(tsMax);
      ev.verifiedAt = dt.toISOString().slice(0, 10) + ' ' + dt.toISOString().slice(11, 16);
    }
    events.push(ev);
  }
  events.sort(function (a, b) { return a.at - b.at; });
  return events;
}

/* one call: GeoJSONs in, HUD-ready route definition + events out */
export function buildRouteEvents(routeGeoJSON, detectionsGeoJSON, opts) {
  opts = opts || {};
  var pathPts = routeFromGeoJSON(routeGeoJSON);
  if (!pathPts) throw new Error('route GeoJSON must contain a LineString');
  var built = buildPath(pathPts);
  var dets = detectionsFromGeoJSON(detectionsGeoJSON);
  var mm = mapDetectionsToRoute(built, dets, opts);
  var events = fuseDetections(mm.mapped, opts);
  return {
    routeDef: {
      name: opts.name || 'mapped-route',
      path: pathPts,
      lanes: opts.lanes || 2,
      laneWidthM: opts.laneWidthM || 3.5,
      laneConfig: opts.laneConfig,
      laneSections: opts.laneSections,
      pois: opts.pois,
      events: events,
    },
    events: events,
    mapped: mm.mapped,
    rejected: mm.rejected,
    stats: {
      detections: dets.length,
      mapped: mm.mapped.length,
      rejected: mm.rejected.length,
      events: events.length,
      routeLengthM: Math.round(built.length),
    },
  };
}
