/* Preloaded Route model (v0.5).
 *
 * The RoadIntel pattern: the full corridor's advisory data (events + lane
 * sections) is downloaded once and cached offline on the assistant device.
 * Everything at runtime is a pure function of (route, progress) — no network,
 * no discovery. Create it once, hand it to the view, feed GPS meters.
 *
 *   const route = createRoute({
 *     name: 'NH-52 Indore \u2192 Bhopal',
 *     length: 45000,
 *     lanes: 4,
 *     laneConfig: { overtaking: 'right' },
 *     laneSections: [                 // from your mapper scans
 *       { from: 0,    quality: [45, 74, 88, 81] },
 *       { from: 8000, quality: [55, 86, 70, 84] },
 *     ],
 *     events: [                       // full corridor, preloaded
 *       { id: 'e1', type: 'pothole', at: 4200, lane: 1, severity: 0.9,
 *         confidence: 'high', verifiedAt: 'today 05:40' },
 *     ],
 *   });
 *
 *   route.laneQualityAt(m)      -> quality array for position m
 *   route.upcoming(m, n)        -> next n events with live distances
 *   route.advisoryAt(m, prev)   -> ranked lanes at m (thread prev for hysteresis)
 *   route.plan(windowM)         -> precomputed advisory windows for the WHOLE
 *                                  route (policy text per window) — schedule
 *                                  voice cues against this before departure
 *   route.eventsBetween(a, b)   -> events overlapping [a, b]
 */
import { getEventType } from './events.js';
import { effectiveLaneQuality, rankLanes, policySentence } from './advisory.js';
import { buildPath, matchToPath, laneFromOffset } from './geo.js';

export function createRoute(def) {
  var events = (def.events || []).slice().sort(function (a, b) { return a.at - b.at; });
  var pois = (def.pois || []).slice().sort(function (a, b) { return a.at - b.at; });
  var sections = (def.laneSections || []).slice().sort(function (a, b) { return a.from - b.from; });
  var lanes = def.lanes || (sections[0] && sections[0].quality.length) || 2;
  var laneWidthM = def.laneWidthM || 3.5;
  var path = def.path ? buildPath(def.path) : null;
  var length = def.length != null ? def.length
    : path ? Math.round(path.length)
    : events.length ? events[events.length - 1].at + 500 : 1000;

  function laneQualityAt(m) {
    if (!sections.length) return null;
    var q = sections[0].quality;
    for (var i = 0; i < sections.length; i++) {
      if (m >= sections[i].from) q = sections[i].quality;
      else break;
    }
    return q;
  }

  function eventsBetween(a, b) {
    var out = [];
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var T = getEventType(ev.type);
      var len = ev.length != null ? ev.length : T.len;
      if (ev.at + len >= a && ev.at <= b) out.push(ev);
    }
    return out;
  }

  function upcoming(m, n) {
    var out = [];
    for (var i = 0; i < events.length && out.length < (n || 3); i++) {
      var ev = events[i];
      var T = getEventType(ev.type);
      var len = ev.length != null ? ev.length : T.len;
      if (ev.at + len < m) continue; // passed
      out.push({
        event: ev,
        name: T.name,
        tone: T.tone,
        distance: Math.max(0, Math.round(ev.at - m)),
        passing: ev.at <= m,
      });
    }
    return out;
  }

  function advisoryAt(m, prev) {
    var effQ = effectiveLaneQuality(laneQualityAt(m), lanes, events, m, 160);
    return rankLanes(effQ, lanes, def.laneConfig, prev, m);
  }

  /* Precompute ranked advisory for the whole corridor in fixed windows.
   * Hysteresis is threaded window-to-window, so this matches exactly what
   * the live HUD will show while driving. Returns:
   *   [{ from, to, advisory, policy }] */
  function plan(windowM) {
    var w = windowM || 200;
    var out = [];
    var prev = null;
    for (var m = 0; m < length; m += w) {
      var adv = advisoryAt(m, prev);
      out.push({ from: m, to: Math.min(m + w, length), advisory: adv, policy: policySentence(adv, w) });
      prev = adv;
    }
    return out;
  }

  /* map-match a GPS fix to route chainage (see geo.js) */
  var lastSeg = null;
  function matchProgress(lat, lng) {
    if (!path) return null;
    var m = matchToPath(path, lat, lng, lastSeg);
    if (!m) return null;
    lastSeg = m.seg;
    var dist = Math.abs(m.offset);
    return {
      progress: m.progress,
      offset: m.offset,
      distance: dist,
      laneGuess: laneFromOffset(m.offset, lanes, laneWidthM),
      onRoute: dist <= 30,
    };
  }

  return {
    name: def.name || 'route',
    length: length,
    lanes: lanes,
    laneWidthM: laneWidthM,
    path: path,
    matchProgress: matchProgress,
    laneConfig: def.laneConfig || {},
    events: events,
    pois: pois,
    laneSections: sections,
    laneQualityAt: laneQualityAt,
    eventsBetween: eventsBetween,
    upcoming: upcoming,
    advisoryAt: advisoryAt,
    plan: plan,
  };
}
