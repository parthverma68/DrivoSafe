/* Scene definitions for react-road-hazards.
 * Pure JS, no platform code. Each scene may define:
 *   id, name              - identifiers
 *   speed                 - world scroll speed (default 0.09)
 *   height(x, zw, f)      - mesh deformation at road-relative x, world z
 *   glow(x, zw, f)        - 0..1 GREEN highlight intensity (informational)
 *   danger(x, zw, f)      - 0..1 RED highlight intensity (warning/severe)
 *   roadCenter(zw, f)     - lateral road path (curves / diversions)
 *   skip(x, zw, f)        - true = missing grid segment (broken road)
 *   geometry(line3, scroll, f) - extra 3D wireframe; line3(...,glow,danger)
 *   defaultLanes / defaultLaneQuality - highway defaults for this scene
 *   overlay               - DEFAULT warning config, user-overridable:
 *       { sign: 'triangle'|'circle'|'arrow'|'x'|'none',
 *         signText: string, text: string,
 *         blink: frames per cycle (0 = steady),
 *         tone: 'danger' (red) | 'accent' (green) }
 */

/* ---------- math helpers ---------- */
export function rnd(x, y) {
  var s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
export function smoothNoise(x, y) {
  var xi = Math.floor(x), yi = Math.floor(y);
  var fx = x - xi, fy = y - yi;
  var sx = fx * fx * (3 - 2 * fx);
  var sy = fy * fy * (3 - 2 * fy);
  var a = rnd(xi, yi), b = rnd(xi + 1, yi);
  var c = rnd(xi, yi + 1), d = rnd(xi + 1, yi + 1);
  var top = a + (b - a) * sx;
  var bot = c + (d - c) * sx;
  return top + (bot - top) * sy;
}
export var gauss = function (d, s) { return Math.exp(-(d * d) / (2 * s * s)); };
export var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
export var localZ = function (zw, P) { return ((zw % P) + P) % P; };
var road = function (x) { return clamp(4.6 - Math.abs(x), 0, 1); };

/* ---------- scenes ---------- */
export var SCENES = [
  {
    id: 'speed-breaker',
    name: 'SPEED BREAKER',
    height: function (x, zw) { return 1.7 * gauss(localZ(zw, 26) - 13, 0.8) * road(x); },
    glow: function (x, zw) { return gauss(localZ(zw, 26) - 13, 1.6) * road(x) * 0.5; },
    danger: function (x, zw) { return gauss(localZ(zw, 26) - 13, 0.8) * road(x); },
    overlay: { sign: 'none', text: 'SPEED BREAKER', blink: 0 },
  },
  {
    id: 'slow-down',
    name: 'SLOW DOWN',
    speed: 0.045,
    danger: function (x, zw, f) {
      return (f % 26 < 13 ? 1 : 0.25) * gauss(localZ(zw, 22) - 11, 1.4) * road(x);
    },
    overlay: { sign: 'triangle', signText: '!', text: 'SLOW DOWN', blink: 26, tone: 'danger' },
  },
  {
    id: 'intersection',
    name: 'INTERSECTION',
    glow: function (x, zw) {
      return Math.abs(localZ(zw, 30) - 15) < 2.2 ? 0.95 : 0;
    },
    overlay: { sign: 'none', text: 'INTERSECTION AHEAD', blink: 0 },
  },
  {
    id: 'bumpy-ride',
    name: 'BUMPY RIDE AHEAD',
    height: function (x, zw) { return 0.8 * smoothNoise(x * 1.3, zw * 1.3) * road(x); },
    danger: function (x, zw) {
      return clamp(smoothNoise(x * 1.3, zw * 1.3) - 0.35, 0, 1) * 1.6 * road(x);
    },
    overlay: { sign: 'triangle', signText: '!', text: 'BUMPY ROAD', blink: 40, tone: 'danger' },
  },
  {
    id: 'undulation',
    name: 'UNDULATION',
    height: function (x, zw) { return 1.3 * Math.sin(zw * 0.55); },
    glow: function (x, zw) { return clamp(Math.sin(zw * 0.55), 0, 1) * 0.8 * road(x); },
    overlay: { sign: 'none', text: 'UNDULATION', blink: 0 },
  },
  {
    id: 'rough-road',
    name: 'ROUGH ROAD',
    height: function (x, zw) {
      return 0.4 * (rnd(Math.round(x), Math.round(zw)) - 0.5) * road(x);
    },
    danger: function (x, zw) {
      return (rnd(Math.round(x) + 3, Math.round(zw)) > 0.7 ? 0.6 : 0) * road(x);
    },
    overlay: { sign: 'none', text: 'ROUGH ROAD', blink: 0 },
  },
  {
    id: 'small-pothole',
    name: 'SMALL POTHOLE',
    height: function (x, zw) {
      return -1.4 * gauss(x - 1.5, 0.8) * gauss(localZ(zw, 24) - 12, 0.8);
    },
    danger: function (x, zw) {
      var r = Math.hypot((x - 1.5) / 1.4, (localZ(zw, 24) - 12) / 1.4);
      return gauss(r - 1, 0.3); // red rim
    },
    overlay: { sign: 'none', text: 'POTHOLE', blink: 0 },
  },
  {
    id: 'big-pothole',
    name: 'BIG POTHOLE',
    height: function (x, zw) {
      return -2.6 * gauss(x, 1.8) * gauss(localZ(zw, 28) - 14, 1.8);
    },
    danger: function (x, zw) {
      var r = Math.hypot(x / 2.8, (localZ(zw, 28) - 14) / 2.8);
      return gauss(r - 1, 0.28);
    },
    overlay: { sign: 'triangle', signText: '!', text: 'BIG POTHOLE', blink: 30, tone: 'danger' },
  },
  {
    id: 'broken-road',
    name: 'BROKEN ROAD',
    height: function (x, zw) {
      return 0.5 * (rnd(Math.round(x) + 7, Math.round(zw)) - 0.5) * road(x);
    },
    danger: function (x, zw) {
      return (rnd(Math.round(x), Math.round(zw) + 5) > 0.8 ? 0.9 : 0) * road(x);
    },
    skip: function (x, zw) {
      return Math.abs(x) < 4.5 && rnd(Math.round(x), Math.floor(zw)) > 0.72;
    },
    overlay: { sign: 'none', text: 'BROKEN ROAD', blink: 0, tone: 'danger' },
  },
  {
    id: 'crack-road',
    name: 'CRACK ROAD',
    height: function (x, zw) { return -0.5 * gauss(x - 2.4 * Math.sin(zw * 0.6), 0.45); },
    danger: function (x, zw) { return gauss(x - 2.4 * Math.sin(zw * 0.6), 0.5) * road(x); },
    overlay: { sign: 'none', text: 'CRACKED SURFACE', blink: 0 },
  },
  {
    id: 'diversion',
    name: 'DIVERSION',
    roadCenter: function (zw) {
      var l = localZ(zw, 34);
      return l > 14 ? clamp((l - 14) * 0.55, 0, 5) : 0;
    },
    overlay: { sign: 'arrow', text: 'DIVERSION', blink: 24 },
  },
  {
    id: 'checkpost',
    name: 'CHECKPOST',
    speed: 0.03,
    glow: function (x, zw) { return gauss(localZ(zw, 30) - 12, 0.6) * road(x) * 0.5; },
    geometry: function (line3, scroll, f) {
      var P = 30;
      var zw0 = Math.ceil((scroll + 1.8) / P) * P + 12;
      var on = f % 16 < 8 ? 1 : 0.35;
      for (var k = 0; k < 2; k++) {
        var z = zw0 - k * P - scroll;
        if (z < 1.8 || z > 38) continue;
        line3(-4, 0, z, -4, 3, z, 1, 0);
        line3(4, 0, z, 4, 3, z, 1, 0);
        for (var s = 0; s < 8; s++) {
          // alternating red/green striped barrier
          if (s % 2 === 0) line3(-4 + s, 3, z, -3 + s, 3, z, 0, on);
          else line3(-4 + s, 3, z, -3 + s, 3, z, 0.6, 0);
        }
      }
    },
    overlay: { sign: 'none', text: 'CHECK POST', blink: 40 },
  },
  {
    id: 'accident',
    name: 'ACCIDENT',
    speed: 0.015,
    geometry: function (line3) {
      boxWire(line3, -2.6, 9, 2.2, 1.4, 0.8, 0, 0.9); // red vehicles
      boxWire(line3, 0.6, 7.8, 2.2, 1.4, 0.8, 0, 0.9);
    },
    overlay: { sign: 'x', text: 'ACCIDENT AHEAD', blink: 16, tone: 'danger' },
  },
  {
    id: 'road-crossing',
    name: 'ROAD CROSSING',
    speed: 0.03,
    glow: zebraGlow,
    overlay: { sign: 'none', text: 'PEDESTRIAN CROSSING', blink: 0 },
  },
  {
    id: 'school-area',
    name: 'SCHOOL AREA',
    speed: 0.03,
    glow: zebraGlow,
    overlay: { sign: 'triangle', signText: '!', text: 'SCHOOL AREA', blink: 40, tone: 'danger' },
  },
  {
    id: 'speed-limit',
    name: 'SPEED LIMIT 40',
    speed: 0.05,
    glow: function (x, zw, f) {
      return (f % 40 < 20 ? 0.6 : 0.2) * gauss(localZ(zw, 24) - 12, 1.2) * road(x);
    },
    overlay: { sign: 'circle', signText: '40', text: 'SPEED LIMIT', blink: 40, tone: 'danger' },
  },
  {
    id: 'curve-road',
    name: 'CURVE ROAD',
    roadCenter: function (zw) { return 3.5 * Math.sin(zw * 0.16); },
    overlay: { sign: 'none', text: 'CURVE AHEAD', blink: 0 },
  },
  {
    id: 'multiple-speed-breakers',
    name: 'MULTIPLE SPEED BREAKERS',
    height: function (x, zw) { return 1.6 * gauss(localZ(zw, 8) - 4, 0.7) * road(x); },
    danger: function (x, zw) { return gauss(localZ(zw, 8) - 4, 0.9) * road(x); },
    overlay: { sign: 'triangle', signText: '!', text: 'MULTIPLE SPEED BREAKERS', blink: 40, tone: 'danger' },
  },
  {
    id: 'lane-quality',
    name: 'HIGHWAY LANE QUALITY',
    defaultLanes: 4,
    defaultLaneQuality: [55, 92, 97, 70],
    overlay: { sign: 'none', text: 'LANE QUALITY', blink: 0 },
  },
];

function zebraGlow(x, zw) {
  var l = localZ(zw, 26);
  if (l < 10 || l > 15) return 0;
  return Math.floor(l) % 2 === 0 ? 0.95 * road(x) : 0;
}

function boxWire(line3, x, z, w, d, h, glow, danger) {
  var c = [
    [x, 0, z], [x + w, 0, z], [x + w, 0, z + d], [x, 0, z + d],
    [x, h, z], [x + w, h, z], [x + w, h, z + d], [x, h, z + d],
  ];
  var e = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
  ];
  for (var i = 0; i < e.length; i++) {
    var a = c[e[i][0]], b = c[e[i][1]];
    line3(a[0], a[1], a[2], b[0], b[1], b[2], glow, danger);
  }
}

export function getScene(id) {
  for (var i = 0; i < SCENES.length; i++) if (SCENES[i].id === id) return SCENES[i];
  return SCENES[0];
}
