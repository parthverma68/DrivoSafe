/* Web renderer: <canvas> + requestAnimationFrame.
 * Written with React.createElement (no JSX) so the package works
 * from node_modules without a build/transpile step.
 */
import React, { useEffect, useRef } from 'react';
import { computeFrame, bucketColor, DEFAULT_THEME, DEFAULT_QUALITY } from '../core/engine.js';

var h = React.createElement;

export default function RoadHazardView(props) {
  var canvasRef = useRef(null);
  var propsRef = useRef(props);
  propsRef.current = props;
  var advisoryRef = useRef(null);  // lane-advisory hysteresis state
  var celebrateRef = useRef(null); // { id, startFrame } for celebration anim

  useEffect(function () {
    var canvas = canvasRef.current;
    var ctx = canvas.getContext('2d');
    var raf, frame = 0;
    var dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;

    function tick() {
      frame++;
      var p = propsRef.current;
      // celebration lifecycle: prop { id, text } -> ~1.6s animation
      var cel = null;
      if (p.celebrate && p.celebrate.id != null) {
        if (!celebrateRef.current || celebrateRef.current.id !== p.celebrate.id) {
          celebrateRef.current = { id: p.celebrate.id, start: frame };
        }
        var ct = (frame - celebrateRef.current.start) / 95;
        if (ct < 1) cel = { t: ct, text: p.celebrate.text };
      }
      var W = p.width || 360;
      var H = p.height || Math.round(W * 0.78);
      var theme = Object.assign({}, DEFAULT_THEME, p.theme);

      if (canvas.width !== W * dpr) {
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        canvas.style.width = W + 'px';
        canvas.style.height = H + 'px';
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      var out = computeFrame({
        mode: p.mode,                 // 'drive' for driver-assistance mode
        sceneId: p.hazard,
        frame: frame,
        width: W,
        height: H,
        quality: p.quality || DEFAULT_QUALITY,
        speed: p.speed,
        overlay: p.warning,           // { sign, signText, text, blink, tone }
        lanes: p.lanes,
        laneQuality: p.laneQuality,
        poles: p.poles,
        advise: p.advise,
        events: p.events,             // drive mode: scanned route events
        progress: p.progress,         // drive mode: current position (m)
        viewDistance: p.viewDistance, // drive mode: view window (m)
        route: p.route,               // preloaded corridor from createRoute()
        showUpcoming: p.showUpcoming, // queue of next N events (needs route/events)
        laneConfig: p.laneConfig,     // { overtaking, minGain, holdMeters, fallbackBand }
        rqi: p.rqi,                   // { score, compliance, harshEvents }
        compliance: p.compliance,     // { score, label } -> top-left trip score
        celebrate: cel,               // internal: animation phase
        environment: p.environment,   // { buildings, village, traffic }
        pois: p.pois,               // amenities along the route
        driverLane: p.driverLane,   // chosen / camera-detected own lane
        detections: p.detections,   // live camera-AI boxes
        show: p.show,               // per-overlay visibility flags
        prevAdvisory: advisoryRef.current,
      });
      if (out.drive && out.drive.advisory) advisoryRef.current = out.drive.advisory;
      if (p.onDriveInfo && out.drive) p.onDriveInfo(out.drive);

      ctx.fillStyle = theme.bg;
      ctx.fillRect(0, 0, W, H);
      ctx.lineWidth = 1;
      ctx.lineCap = 'round';

      // batched wireframe
      for (var i = 0; i < out.paths.length; i++) {
        var b = out.paths[i];
        ctx.strokeStyle = bucketColor(b, theme);
        ctx.beginPath();
        var pts = b.points;
        for (var j = 0; j < pts.length; j += 4) {
          ctx.moveTo(pts[j], pts[j + 1]);
          ctx.lineTo(pts[j + 2], pts[j + 3]);
        }
        ctx.stroke();
      }

      // overlays
      for (var k = 0; k < out.overlays.length; k++) {
        drawOverlay(ctx, out.overlays[k], W, H, theme);
      }

      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return function () { cancelAnimationFrame(raf); };
  }, []);

  return h('canvas', {
    ref: canvasRef,
    style: Object.assign({ display: 'block', borderRadius: 8 }, props.style),
  });
}

function toneColor(theme, tone, a) {
  var c = tone === 'danger' ? (theme.danger || [255, 92, 96])
    : tone === 'warn' ? (theme.warn || [255, 190, 80])
    : tone === 'neutral' ? theme.grid
    : theme.glow;
  return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
}

function drawOverlay(ctx, ov, W, H, theme) {
  var x = ov.x * W, y = ov.y * H;
  var a = ov.on ? 1 : 0.35;
  var col = toneColor(theme, ov.tone, a);
  ctx.strokeStyle = col;
  ctx.fillStyle = col;
  ctx.lineWidth = 2.5;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  if (ov.kind === 'banner') {
    ctx.font = 'bold 16px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text, x, y);
  } else if (ov.kind === 'label') {
    ctx.font = 'bold 13px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text, x, y);
  } else if (ov.kind === 'subline') {
    ctx.font = '10px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text, x, y);
  } else if (ov.kind === 'queue') {
    ctx.font = '10px ui-monospace, Menlo, monospace';
    ctx.textAlign = 'right';
    ctx.fillText(ov.text, x, y);
    ctx.textAlign = 'center';
  } else if (ov.kind === 'you') {
    // upward triangle marker + label for the driver's own lane
    ctx.beginPath();
    ctx.moveTo(x, y - 14);
    ctx.lineTo(x - 8, y - 2);
    ctx.lineTo(x + 8, y - 2);
    ctx.closePath();
    ctx.fill();
    ctx.font = 'bold 9px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text, x, y + 6);
  } else if (ov.kind === 'det-label') {
    ctx.font = 'bold 10px ui-monospace, Menlo, monospace';
    ctx.lineWidth = 3;
    ctx.strokeStyle = theme.bg;
    ctx.strokeText(ov.text, x, y);
    ctx.fillText(ov.text, x, y);
  } else if (ov.kind === 'poi-label') {
    ctx.font = 'bold 9px ui-monospace, Menlo, monospace';
    ctx.globalAlpha = 0.9;
    ctx.fillText(ov.text, x, y);
    ctx.globalAlpha = 1;
  } else if (ov.kind === 'lane-num') {
    // dark outline so the number reads against the grid lines
    ctx.font = 'bold 15px ui-monospace, Menlo, monospace';
    ctx.lineWidth = 4;
    ctx.strokeStyle = theme.bg;
    ctx.strokeText(ov.text, x, y);
    ctx.fillText(ov.text, x, y);
  } else if (ov.kind === 'score') {
    ctx.font = 'bold 13px ui-monospace, Menlo, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(ov.text, x, y);
    ctx.textAlign = 'center';
  } else if (ov.kind === 'celebrate') {
    drawCelebrate(ctx, ov, x, y, W, H, theme);
  } else if (ov.kind === 'lane-label') {
    ctx.font = 'bold 12px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text, x, y);
    if (ov.roleText) {
      ctx.font = 'bold 8px ui-monospace, Menlo, monospace';
      ctx.fillText(ov.roleText, x, y - H * 0.042);
    }
  } else if (ov.kind === 'sign-triangle') {
    ctx.beginPath();
    ctx.moveTo(x, y - 15);
    ctx.lineTo(x + 16, y + 12);
    ctx.lineTo(x - 16, y + 12);
    ctx.closePath();
    ctx.stroke();
    ctx.font = 'bold 14px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text || '!', x, y + 5);
  } else if (ov.kind === 'sign-circle') {
    var r = Math.min(W, H) * 0.075;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.font = 'bold ' + Math.round(r) + 'px ui-monospace, Menlo, monospace';
    ctx.fillText(ov.text || '', x, y + 1);
  } else if (ov.kind === 'sign-arrow') {
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x - 20, y);
    ctx.lineTo(x + 16, y);
    ctx.lineTo(x + 6, y - 9);
    ctx.moveTo(x + 16, y);
    ctx.lineTo(x + 6, y + 9);
    ctx.stroke();
  } else if (ov.kind === 'sign-x') {
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(x - 11, y - 11);
    ctx.lineTo(x + 11, y + 11);
    ctx.moveTo(x + 11, y - 11);
    ctx.lineTo(x - 11, y + 11);
    ctx.stroke();
  }
}


/* winning arrow + stars: phase 0..1 */
function drawCelebrate(ctx, ov, x, y, W, H, theme) {
  var t = ov.phase;
  var rise = 34 * Math.min(1, t * 2.2);
  var alpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
  var pop = t < 0.18 ? t / 0.18 : 1; // scale-in
  var cy = y - rise;
  var col = toneColor(theme, 'accent', alpha);
  ctx.strokeStyle = col;
  ctx.fillStyle = col;
  ctx.lineWidth = 4 * pop;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  var s = 26 * pop;
  // upward arrow
  ctx.beginPath();
  ctx.moveTo(x, cy + s);
  ctx.lineTo(x, cy - s * 0.9);
  ctx.moveTo(x - s * 0.62, cy - s * 0.2);
  ctx.lineTo(x, cy - s * 0.9);
  ctx.lineTo(x + s * 0.62, cy - s * 0.2);
  ctx.stroke();
  // orbiting / bursting stars
  var n = 6;
  for (var k = 0; k < n; k++) {
    var ang = (k / n) * Math.PI * 2 + t * 2.2;
    var r = 26 + 44 * t;
    var sx = x + Math.cos(ang) * r;
    var sy = cy - s * 0.1 + Math.sin(ang) * r * 0.62;
    var tw = 0.6 + 0.4 * Math.sin(t * 22 + k * 1.7); // twinkle
    drawStar(ctx, sx, sy, 5.5 * pop * tw, toneColor(theme, 'accent', alpha * tw));
  }
  // label
  ctx.fillStyle = toneColor(theme, 'accent', alpha);
  ctx.font = 'bold 13px ui-monospace, Menlo, monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(ov.text, x, cy + s + 20);
}
function drawStar(ctx, x, y, r, col) {
  ctx.fillStyle = col;
  ctx.beginPath();
  for (var i = 0; i < 10; i++) {
    var rad = i % 2 === 0 ? r : r * 0.45;
    var a = (i / 10) * Math.PI * 2 - Math.PI / 2;
    var px = x + Math.cos(a) * rad, py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
}
